from __future__ import annotations
_J='dataclasses.replace'
_I='dataclasses.astuple'
_H='dataclasses.asdict'
_G='dataclass'
_F='dataclasses.dataclass'
_E='dataclasses'
_D='__init__'
_C=False
_B=None
_A=True
import ast,logging,re
from dataclasses import KW_ONLY,dataclass,fields,replace
from enum import Enum,auto
from typing import TYPE_CHECKING,Final,Literal,assert_type,final
from typing_extensions import override
from mambalade.asthelpers import expr_matches_module_attr,str_ast
from mambalade.calls import AbstractArgs,CallData,MatchResult,Param,ParameterList,may_args_match_params
from mambalade.listeners import Listener,ListenerKey
from mambalade.natives.core import Type
from mambalade.natives.helpers import NativeType,native_function,native_method,native_type,return_unknown,unsupported_native
from mambalade.options import MAMBALADE_DEBUG
from mambalade.tokens import AccessPathToken,ClassToken,InstanceToken,ObjectToken,Token,TypeToken,UnknownToken
from mambalade.vars import ConstraintVar,NodeVar,PropVar,constraintvar
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.operations import Operations;from mambalade.visitors.analysis import AnalysisVisitor
logger=logging.getLogger(__name__)
@dataclass(kw_only=_A)
class _DataclassParams:init:bool=_A;repr:bool=_A;eq:bool=_A;order:bool=_C;unsafe_hash:bool=_C;frozen:bool=_C;match_args:bool=_A;kw_only:bool=_C;slots:bool=_C;weakref_slot:bool=_C
@native_function(_F,spec=f"lambda cls=None, /, *, {", ".join(f"{A.name}={A.default!r}"for A in fields(_DataclassParams))}, **kwargs: 0")
def dataclass_decorator(op,d):
	A=op
	if d.args.unpack_iter is not _B:A.a.warn_unsupported(d.callnode,'dataclasses.dataclass with iterable unpacking');return
	if not d.args.args:A.return_value(d,dataclass_decorator);return
	def B(t):
		if isinstance(t,ClassToken):_construct_dataclass(A,d,t)
		else:
			if not isinstance(t,UnknownToken|AccessPathToken|DataclassToken):assert_type(t,ObjectToken);A.a.warn_unsupported(d.callnode,f"dataclasses.dataclass non-class argument {type(t)}")
			A.return_value(d,t)
	if isinstance((C:=d.args.args[0]),Token|ConstraintVar):A.solver.add_forall_constraint(C,ListenerKey(Listener.NATIVE_DATACLASS_DECORATOR,parent=d.parent),B)
@final
class _FieldType(Enum):NORMAL=auto();CLASSVAR=auto();INITVAR=auto()
@final
class _Missing(Enum):MISSING=auto()
_MISSING=_Missing.MISSING
@final
@dataclass(slots=_A)
class _Field:name:Final[str];type:Final[_FieldType];_:KW_ONLY;init:Final[bool];kw_only:Final[bool];default:Final[ConstraintVar|Literal[_Missing.MISSING]|_B]
@final
@constraintvar
class DataclassInitParamVar(ConstraintVar):
	obj:Final[ObjectToken];field:Final[str]
	def __str__(A):return f"DataclassInitParamVar[{A.obj}.{A.field}]"
@final
class DataclassToken(TypeToken):
	typ=Type;immutable=_C
	def __init__(B,cls,d_params,fields,annotations):
		F=fields;C=cls;assert C.mro[0]is C;B.mro=B,*C.mro[1:];B.cls=C;B.params=d_params;B.fields=F;B.annotations=annotations;D=[Param('self',0,has_default=_C)];E={}
		for A in F.values():
			if A.init and A.type!=_FieldType.CLASSVAR:
				if A.kw_only:E[A.name]=Param(A.name,_B,has_default=A.default is not _MISSING)
				else:D.append(Param(A.name,len(D),has_default=A.default is not _MISSING));E[A.name]=D[-1]
		B.init_params=ParameterList(D,E)
	@override
	def __str__(self):return f"DataclassToken({self.cls})"
	@override
	def __eq__(B,A):return isinstance(A,DataclassToken)and B.cls==A.cls
	@override
	def __hash__(self):return hash((type(self),self.cls))
	@property
	def user_defined(self):return self.cls.user_defined
	@override
	def new_instance(A,B,C):return InstanceToken(A)
	@override
	def _lookup_attr(A,B):
		if B==_D and A.params.init:return A._known_slots[_D],_A
		if(C:=A.fields.get(B))is not _B and B in A.annotations:
			if C.type is _FieldType.NORMAL and C.default is not _MISSING:return C.default,_A
			elif C.type is _FieldType.CLASSVAR:return PropVar(A,B),C.default is not _MISSING
		return A.cls.lookup_attr(B)
	@native_type(tname=_F)
	class Helper(NativeType):
		@native_method(_D,spec='lambda self, /, *args, **kwargs: 1')
		@staticmethod
		def init(op,d):
			D=op;A=d.args
			if not isinstance((C:=A.args[0]),ObjectToken):logger.debug('Ignoring dataclasses.dataclass.__init__ on non-constant object %s',C);return
			for B in C.typ.mro:
				if isinstance(B,DataclassToken)and B.params.init:break
			else:logger.debug('Ignoring dataclasses.dataclass.__init__ on non-dataclass object %s',C);return
			J=B.init_params
			match may_args_match_params(A,J):
				case MatchResult(L,H,M):pass
				case N,A:
					if logger.isEnabledFor(logging.DEBUG):logger.debug('Incompatible arguments for dataclass at %s (fields: %s): %s',d.callnode,B.fields,N%A)
					return
			def I(name):A=name;return PropVar(C,A)if B.fields[A].type==_FieldType.NORMAL else DataclassInitParamVar(C,A)
			assert len(A.args)<=H
			for(E,F)in zip(A.args[1:H],J.params[1:],strict=_C):
				assert not(MAMBALADE_DEBUG and B.fields[F.name].kw_only)
				if isinstance(E,Token|ConstraintVar):D.inclusion_constraint(E,I(F.name))
			if len(A.args)<H and A.unpack_iter is not _B:
				vars=[]
				for F in J.params[len(A.args):H]:assert not(MAMBALADE_DEBUG and B.fields[F.name].kw_only);vars.append(I(F.name))
				D.unpack_iterable_into_vars(vars,_B,A.unpack_iter,d.callnode,d.caller,ListenerKey(Listener.NATIVE_DATACLASS__INIT__UNPACK,token=C,parent=d.parent))
			if A.kwargs is not _B:
				if M:D.a.warn_unsupported(d.callnode,'Mapping unpacking in dataclasses.dataclass.__init__')
				for(K,E)in A.kwargs:
					if K is not _B and isinstance(E,Token|ConstraintVar):D.inclusion_constraint(E,I(K))
			for G in B.fields.values():
				if G.default is not _MISSING and(not G.init or G.name not in L):D.inclusion_constraint(G.default,I(G.name))
			O=ListenerKey(Listener.NATIVE_DATACLASS__INIT__POST,parent=d.parent);D.invoke_special_method(C,'__post_init__',replace(d,args=AbstractArgs.seq(*[DataclassInitParamVar(C,A.name)for A in B.fields.values()if A.type==_FieldType.INITVAR]),res=_B,parent=O))
	_known_slots:Final=Helper.known_slots;del Helper
def _construct_dataclass(op,d,ct):
	D=ct;A=op;E=D.cls.node
	if not E.decorator_list:A.a.warn_unsupported(d.callnode,'dataclasses.dataclass on class without decorators');A.return_value(d,D);return
	F=A.a.class_info[E];U=_D not in F.declarations;B=_DataclassParams(init=U)
	for G in E.decorator_list:
		if isinstance(G,ast.Call)and expr_matches_module_attr(G.func,_E,_G):
			for L in G.keywords:
				match(L.arg,L.value):
					case str(M),ast.Constant(bool(V))if hasattr(B,M):setattr(B,M,V)
					case _:A.a.warn_unsupported(d.callnode,'Unsupported dataclasses.dataclass argument')
	H={};I=_C;N=_C
	for J in D.mro[-1:0:-1]:
		if isinstance(J,DataclassToken):
			N=_A
			for C in J.fields.values():H[C.name]=C
			if J.params.frozen:I=_A
	if N:
		if I and not B.frozen:A.a.warn_unsupported(d.callnode,'Assuming frozen=True in dataclass with frozen base');B.frozen=_A
		if not I and B.frozen:A.a.warn_unsupported(d.callnode,'Ignoring frozen=True in dataclass with non-frozen bases');B.frozen=_C
	O=A.a.modules[D.cls.module].visitor;assert O is not _B;P=B.kw_only;Q=[]
	for(R,S)in F.annotations.items():
		if expr_matches_module_attr(S.annotation,_E,'KW_ONLY',allow_string=_A):P=_A
		else:
			C=_get_field(A,d,O,E,R,S,kw_only=P);H[R]=C
			if C.type is _FieldType.CLASSVAR:Q.append(C)
	T=DataclassToken(D,B,H,F.annotations);A.return_value(d,T)
	for K in Q:
		if K.default is not _MISSING:A.inclusion_constraint(K.default,PropVar(T,K.name))
@final
@constraintvar
class DefaultFactoryResultVar(NodeVar[ast.ClassDef]):
	field:Final[str]
	def __str__(A):return f"DefaultFactoryResultVar[{str_ast(A.node)}.{A.field}] @ {A.context}"
_initvar_re=re.compile('(?:dataclasses\\.)?InitVar(?:\\[.*\\])?')
_classvar_re=re.compile('(?:typing\\.)?ClassVar(?:\\[.*\\])?')
def _get_field(op,d,visitor,cls,name,ann,*,kw_only):
	L=kw_only;H=ann;G=name;F=visitor;M=_A;B=_MISSING;C=_FieldType.NORMAL
	match H.annotation:
		case ast.Subscript(value=I)if expr_matches_module_attr(I,_E,'InitVar'):C=_FieldType.INITVAR
		case ast.Constant(str(J))if _initvar_re.fullmatch(J):C=_FieldType.INITVAR
		case ast.Subscript(value=I)if expr_matches_module_attr(I,'typing','ClassVar'):C=_FieldType.CLASSVAR
		case ast.Constant(str(J))if _classvar_re.fullmatch(J):C=_FieldType.CLASSVAR
		case _:pass
	if H.value is not _B:
		D=d.context
		match H.value:
			case ast.Call(E,keywords=N)if expr_matches_module_attr(E,_E,'field'):
				for K in N:
					match(K.arg,K.value):
						case'default',A:B=F.get_var(K.value,context=D)
						case'default_factory',A:
							E=F.get_var(A,context=D)
							if E is _B:B=_B
							else:B=DefaultFactoryResultVar(cls,D,G);O=ListenerKey(Listener.NATIVE_DATACLASS_FIELD_DEFAULT_FACTORY,string=G,parent=d.parent);op.invoke_object(E,replace(d,args=AbstractArgs.empty,res=B,parent=O))
						case'init',ast.Constant(bool(A)):M=A
						case'kw_only',ast.Constant(bool(A)):L=A
						case _:pass
			case A:B=F.get_var(A,context=D)
	return _Field(G,C,init=M,kw_only=L,default=B)
@native_function('dataclasses.field',spec='lambda *, default=MISSING, default_factory=MISSING,     init=True, repr=True, hash=None, compare=True, metadata=None, kw_only=MISSING, **kwargs: 0')
def field(op,d):
	if d.args.kwargs:
		for(A,B)in d.args.kwargs:
			if A is _B:op.a.warn_unsupported(d.callnode,'dataclasses.field with mapping unpacking')
@native_function(_H,spec='lambda obj, *, dict_factory=dict: 0')
def asdict(op,d):op.a.warn_unsupported(d.callnode,_H);op.return_value(d,UnknownToken())
@native_function(_I,spec='lambda obj, *, tuple_factory=tuple: 0')
def astuple(op,d):op.a.warn_unsupported(d.callnode,_I);op.return_value(d,UnknownToken())
@native_function(_J,spec='lambda obj, /, **changes: 0')
def replace_model(op,d):op.a.warn_unsupported(d.callnode,_J);op.invoke_unknown(d)
model={_G:dataclass_decorator,'field':field,'asdict':asdict,'astuple':astuple,'replace':replace_model,'make_dataclass':unsupported_native('dataclasses.make_dataclass',return_unknown)}