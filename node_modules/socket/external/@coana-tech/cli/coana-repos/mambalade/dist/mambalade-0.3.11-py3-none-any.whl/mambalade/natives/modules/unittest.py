from __future__ import annotations
from typing import TYPE_CHECKING,Final
from mambalade.natives.builtin_functions import strict_identity_decorator
from mambalade.natives.helpers import native_function
if TYPE_CHECKING:from mambalade.calls import CallData;from mambalade.operations import Operations
@native_function('unittest.skip',spec='lambda reason: 0')
def skip(op,d):op.return_value(d,strict_identity_decorator)
@native_function('unittest.skipIf',spec='lambda condition, reason: 0')
def skipIf(op,d):op.return_value(d,strict_identity_decorator)
model={'skip':skip,'skipIf':skipIf,'skipUnless':skipIf,'expectedFailure':strict_identity_decorator}