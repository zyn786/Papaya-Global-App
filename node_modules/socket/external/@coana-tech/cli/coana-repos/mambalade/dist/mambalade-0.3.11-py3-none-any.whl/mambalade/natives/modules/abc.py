from __future__ import annotations
from typing import TYPE_CHECKING
from mambalade.natives.builtin_functions import strict_identity_decorator
from mambalade.natives.core import Object,Type
from mambalade.natives.functions import ClassMethod,StaticMethod
from mambalade.natives.helpers import NativeType,native_type
from mambalade.natives.property import Property
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.tokens import NativeToken
@native_type(Type,Object,tname='abc.ABCMeta',mark_unsupported=True)
class ABCMeta(NativeType):0
@native_type(Object,tname='abc.ABC')
class ABC(NativeType):0
model={'abstractmethod':strict_identity_decorator,'abstractproperty':Property,'abstractclassmethod':ClassMethod,'abstractstaticmethod':StaticMethod,'ABC':ABC,'ABCMeta':ABCMeta}