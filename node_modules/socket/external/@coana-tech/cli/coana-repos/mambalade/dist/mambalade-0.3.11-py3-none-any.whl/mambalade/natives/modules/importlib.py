from __future__ import annotations
import importlib.util,logging
from typing import TYPE_CHECKING
from mambalade.infos import ModuleIdentifier
from mambalade.natives.helpers import native_function
from mambalade.tokens import UnknownToken
if TYPE_CHECKING:from mambalade.calls import CallData;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
@native_function('importlib.import_module',spec='lambda name, package = None: 1')
def import_module(op,d):
	B=None;A=op;D=d.args.args;E=D[0]
	if not isinstance(E,str):A.a.warn_unsupported(d.callnode,'importlib.import_module with non-constant module name');A.return_value(d,UnknownToken());return
	if d.args.unpack_iter is not B:A.a.warn_unsupported(d.callnode,'importlib.import_module with iterable unpacking');A.return_value(d,UnknownToken());return
	C=D[1]if len(D)==2 else B
	if d.args.kwargs:
		for(F,H)in d.args.kwargs:
			if F is B:A.a.warn_unsupported(d.callnode,'importlib.import_module with **kwargs');A.return_value(d,UnknownToken());return
			assert F=='package';C=H
	if C is not B and not isinstance(C,str):A.a.warn_unsupported(d.callnode,'importlib.import_module with non-constant package name');A.return_value(d,UnknownToken());return
	try:I=ModuleIdentifier(importlib.util.resolve_name(E,C))
	except ImportError:A.a.diagnostics.failed_relative_imports+=1;logger.error("Relative import '%s' failed at %s",E,d.callnode);A.return_value(d,UnknownToken())
	else:
		J,G=A.import_module(I,d.callnode.node,d.caller);A.return_value(d,J)
		if G is not B:A.return_value(d,G)
model={'import_module':import_module}