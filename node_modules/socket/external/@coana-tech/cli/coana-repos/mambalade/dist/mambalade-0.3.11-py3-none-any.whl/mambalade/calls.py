from __future__ import annotations
_B=True
_A=None
import ast,inspect
from collections.abc import Callable,Generator,Mapping,Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING,Any,ClassVar,Final,NamedTuple,TypeAlias,cast,final
from.contexts import Context,EmptyContext
from.options import MAMBALADE_DEBUG
from.tokens import Token
from.vars import ConstraintVar
if TYPE_CHECKING:from.infos import CallEdgeSource,QualifiedNode;from.listeners import ListenerKey
AbstractArg=Token|str|int|ConstraintVar|ast.Slice|_A
AbstractKWArgs=Sequence[tuple[str|_A,AbstractArg]]|_A
@final
@dataclass(frozen=_B,slots=_B)
class AbstractArgs:
	num_definite_pos_args:Final[int];args:Final[tuple[AbstractArg,...]];unpack_iter:Final[Token|ConstraintVar|_A]=_A;kwargs:Final[AbstractKWArgs]=_A;empty:ClassVar[AbstractArgs]=cast('Any',_A)
	@classmethod
	def seq(B,*A):return B.empty if not A else B(len(A),A)
	def prepend(A,*B):return AbstractArgs(A.num_definite_pos_args+len(B),B+A.args,A.unpack_iter,A.kwargs)
	def shift(A):assert A.args;return AbstractArgs(A.num_definite_pos_args-1,A.args[1:],A.unpack_iter,A.kwargs)
	def __post_init__(A):
		if A.unpack_iter is _A:assert A.num_definite_pos_args==len(A.args)
		else:assert A.num_definite_pos_args>=len(A.args)
AbstractArgs.empty=AbstractArgs(0,())
ResultHandler=Callable[[Token|ConstraintVar],_A]|ConstraintVar|_A
@final
@dataclass(frozen=_B,slots=_B)
class CallData:
	args:Final[AbstractArgs];res:Final[ResultHandler];callnode:Final[QualifiedNode];caller:Final[CallEdgeSource];parent:Final[ListenerKey]
	@property
	def context(self):return EmptyContext()if isinstance(self.caller,str)else self.caller.context
@final
@dataclass(frozen=_B,slots=_B)
class Param:name:Final[str];index:Final[int|_A];has_default:Final[bool]
@final
@dataclass(slots=_B)
class ParameterList:
	params:Final[Sequence[Param]];param_by_name:Final[Mapping[str,Param]];vararg:Final[str|_A]=_A;kwarg:Final[str|_A]=_A
	if MAMBALADE_DEBUG:
		def __post_init__(A):
			for B in A.params:assert B.index is not _A,'Positional params must have an index'
	@classmethod
	def from_ast(F,params):
		A=params;C=[];D={};G=len(A.defaults);H=len(A.posonlyargs)+len(A.args)
		for(E,B)in enumerate(A.posonlyargs+A.args):
			C.append(Param(B.arg,E,E>=H-G))
			if E>=len(A.posonlyargs):D[B.arg]=C[-1]
		for(B,I)in zip(A.kwonlyargs,A.kw_defaults,strict=_B):D[B.arg]=Param(B.arg,_A,I is not _A)
		return F(C,D,_A if A.vararg is _A else A.vararg.arg,_A if A.kwarg is _A else A.kwarg.arg)
	@classmethod
	def from_signature(G,sig):
		B=[];C={};D=_A;E=_A
		for(F,A)in enumerate(sig.parameters.values()):
			match A.kind:
				case A.POSITIONAL_ONLY:B.append(Param(A.name,F,A.default is not inspect.Parameter.empty))
				case A.POSITIONAL_OR_KEYWORD:B.append(Param(A.name,F,A.default is not inspect.Parameter.empty));C[A.name]=B[-1]
				case A.VAR_POSITIONAL:D=A.name
				case A.KEYWORD_ONLY:C[A.name]=Param(A.name,_A,A.default is not inspect.Parameter.empty)
				case A.VAR_KEYWORD:E=A.name
		return G(B,C,D,E)
	def pos_only(A,name):return name not in A.param_by_name
	def valid_kw_arg(A,name):return name in A.param_by_name
	def all_parameter_names(A):
		for B in A.params:
			if B.name not in A.param_by_name:yield B.name
		yield from A.param_by_name.keys()
@final
class MatchResult(NamedTuple):param_filled:set[str];break_pos_at:int;has_kw_unpack:bool
def may_args_match_params(args,pl):
	E=args;B=pl;F=set[str]();C=len(B.params);G=False
	if(H:=E.kwargs)is not _A:
		for(D,L)in H:
			if D is _A:G=_B;continue
			if not B.valid_kw_arg(D):
				if B.kwarg is not _A:continue
				return'Unexpected keyword argument %s',(D,)
			if D in F:return'Multiple values for argument %s',(D,)
			F.add(D)
			if(I:=B.param_by_name[D].index)is not _A:C=min(C,I)
	if E.num_definite_pos_args>C:
		if C<len(B.params):return'Too many positional arguments (broken) (%d > %d)',(E.num_definite_pos_args,C)
		elif B.vararg is _A:return'Too many positional arguments (%d > %d)',(E.num_definite_pos_args,C)
	J=E.unpack_iter is not _A;F.update(A.name for A in B.params[:E.num_definite_pos_args])
	for A in B.params:
		if A.has_default or A.name in F:continue
		assert A.index is not _A;K=A.index<C and J or B.valid_kw_arg(A.name)and G
		if not K:return'Missing value for argument %s',(A.name,)
	for A in B.param_by_name.values():
		if A.index is not _A or A.has_default or A.name in F:continue
		if not G:return'Missing value for kw-only argument %s',(A.name,)
	return MatchResult(F,C,G)