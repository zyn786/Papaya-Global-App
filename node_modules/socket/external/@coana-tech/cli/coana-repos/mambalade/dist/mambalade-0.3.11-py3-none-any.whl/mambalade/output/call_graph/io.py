from __future__ import annotations
import json
from typing import IO,TYPE_CHECKING,AnyStr,TextIO,TypedDict,cast
if TYPE_CHECKING:from collections.abc import Callable;from mambalade.infos import ModuleIdentifier;from.types import SerializedCallGraph,SerializedModule,SerializedTarget
class _DiskCG(TypedDict('Optional',{'entries':list[int],'contexts':list[str]},total=False)):modules:list[list[ModuleIdentifier|str]|ModuleIdentifier];targets:list[list[int|str]];edges:list[list[int]]
dump_to_file=json.dump
def _parse_target(target):B,C,*A=target;assert isinstance(B,int)and isinstance(C,str)and 1<=len(A)<=3 and all(isinstance(A,int)for A in A);return B,C,*cast('tuple[int]',tuple(A))
def _parse_module(module):
	A=module
	if isinstance(A,str):return A,
	assert 1<=len(A)<=2;return cast('SerializedModule',tuple(A))
def load_from_file(file):D='targets';C='modules';B='edges';A=json.load(file);assert isinstance(A,dict);assert{C,D,B}<=A.keys();assert all(len(A)==2 for A in A[B]);return{**A,C:[_parse_module(A)for A in A[C]],D:[_parse_target(A)for A in A[D]],B:[tuple[int,int](A)for A in A[B]]}