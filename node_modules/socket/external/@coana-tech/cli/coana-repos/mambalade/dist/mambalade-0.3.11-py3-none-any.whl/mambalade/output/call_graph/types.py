from __future__ import annotations
from typing import TYPE_CHECKING,NotRequired,TypeAlias,TypedDict
if TYPE_CHECKING:from collections.abc import Sequence;from mambalade.infos import ModuleIdentifier;_BaseTarget=tuple[int,str,int];SerializedTarget=_BaseTarget|tuple[*_BaseTarget,int]|tuple[*_BaseTarget,int,int];SerializedModule=tuple[ModuleIdentifier]|tuple[ModuleIdentifier,str]
class _StableCGFields(TypedDict):modules:Sequence[SerializedModule];targets:Sequence[SerializedTarget];edges:Sequence[tuple[int,int]];contexts:NotRequired[Sequence[str]]
class _V1CG(_StableCGFields,total=False):entries:Sequence[int]
class V2SerializedCallGraph(_StableCGFields,total=False):target_entries:Sequence[int]
SerializedCallGraph=_V1CG|V2SerializedCallGraph