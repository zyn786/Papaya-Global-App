from __future__ import annotations
_E='Function not reachable from application code'
_D='Function not found'
_C='Module not analyzed'
_B=True
_A=False
import itertools,logging,os.path
from collections import Counter,defaultdict
from fnmatch import fnmatch
from typing import TYPE_CHECKING,Literal,NamedTuple,TypeAlias,cast,final
import networkx as nx
from.import distributions,graph
from.asthelpers import ASTLocation,DummyASTLocation,loc_ast,str_ast
from.contexts import EmptyContext
from.infos import CallEdgeKind,CallEdgeSource,FunctionInfo,ModuleIdentifier,ModuleKind,Native,NodeSource,source_module
from.util import simple_cache
if TYPE_CHECKING:import ast;from collections.abc import Iterable;from.accesspathmanager import AccessPathsManager;from.globalstate import GlobalState
logger=logging.getLogger(__name__)
@final
class SourceLocation(NamedTuple):
	filename:str;loc:ASTLocation
	def __str__(A):return f"{A.filename}:{A.loc}"
@final
class CallPathNode(NamedTuple):package:str;caller:CallEdgeSource;source_location:SourceLocation;confidence:float
VulnerableResult=list[tuple[CallPathNode,...]]
UnreachableReason=Literal[_C,_D,_E]
VulnerabilityResults=dict[str,tuple[Literal[_A],UnreachableReason]|tuple[Literal[_B],VulnerableResult]]
def _strip_contexts(sources):return{A if isinstance(A,str)else A.namespace for A in sources}
def analyze_vulnerabilities(a,vulns,*,deterministic_paths=_A,max_paths=10):
	o='sink';n='source';m='weight';Z=vulns;Y=.0;O=max_paths;N=1.;H='<app>';E=None
	if not Z:return{}
	@simple_cache
	def b(id):
		match a.modules[id].kind:
			case ModuleKind.APP:return H
			case ModuleKind.LIBRARY:A=id.partition('.')[0];return p.get(A,A)
			case _:return
	def I(t):return b(source_module(t))
	with a.diagnostics.time('vuln_analysis'):
		p=distributions.pkg_to_dist(a.program.sys_path);P=defaultdict[str,list[CallEdgeSource]](list)
		for J in a.node_info.values():
			if isinstance(J,FunctionInfo):P[J.fully_qualified_name].extend(NodeSource(J.node,A)for A in J.reachable_contexts or[EmptyContext()])
		for K in a.modules:P[f"{K}:<module>"].append(K)
		Q=defaultdict[CallEdgeSource,set[CallEdgeSource]](set)
		for((G,c),R)in a.call_edges.items():
			for(c,A)in R:
				if not isinstance(A,Native):Q[G].add(A)
		d=[A for A in Q if I(A)==H];e=graph.transitive_closure(Q.__getitem__,d);logger.info('Targets reachable from application code: %d (%d non-app)',(q:=len(_strip_contexts(e))),q-len(_strip_contexts(d)));F={};S=[]
		for B in Z:
			if is_access_path_vuln(B):T=_find_access_path_matches(a.access_paths_manager,B)
			else:
				K,r,c=B.partition(':')
				if not r:logger.error('Invalid vulnerability ID %s',B);continue
				if K not in a.modules:F[B]=_A,_C;continue
				T=P.get(B)
			if T is E:logger.error("Node matching vulnerability '%s' not found",B);F[B]=_A,_D;continue
			if not(U:=set(T)&e):F[B]=_A,_E;continue
			S.append((B,U))
	with a.diagnostics.time('vuln_paths'):
		if not S:return F
		s=Counter((B,D)for((A,B),C)in a.call_edges.items()for(D,A)in C)
		def V(node,kind):
			match kind:
				case CallEdgeKind.NORMAL:A=N
				case CallEdgeKind.ESCAPED:A=1e2
				case CallEdgeKind.COROUTINE|CallEdgeKind.IMPORT:A=1e1
				case CallEdgeKind.NATIVE:raise AssertionError('Unreachable')
			B=s[node,kind];C=B**1.5*A;D=(N/B)**.5/max(N,A/9.);return C,D
		if deterministic_paths:
			f={B:A for(A,(C,B))in enumerate(sorted(a.call_edges,key=lambda x:(str(x[0]),str_ast(x[1]))))};t=len(f);u=V
			def V(node,kind):A,B=u(node,kind);return A*t+f[node],B
		C=nx.DiGraph()
		for((G,L),R)in a.call_edges.items():
			g=_A
			for(v,A)in R:
				if not isinstance(A,Native)and I(A)!=H:
					g=_B;h,w=V(L,v);C.add_edge(L,A);i=C.edges[L,A]
					if h<i.get(m,float('inf')):i.update(weight=h,confidence=w)
			if g:
				if I(G)==H:C.add_edge(n,G,weight=Y)
				C.add_edge(G,L,weight=Y)
		def j(caller,callnode,confidence=N):C=callnode;B=caller;D=a.modules[source_module(B)];F=b(D.name);A=D.spec.origin;assert A is not E and F is not E;G=os.path.relpath(A,a.options.root_dir);return CallPathNode(package=F,caller=B,source_location=SourceLocation(G if not G.startswith('..')else A,loc_ast(C,one_indexed_col=_B)if C is not E else DummyASTLocation()),confidence=confidence)
		for(B,U)in S:
			D={};W=[]
			for A in U:
				if I(A)==H:
					D[j(A,A.namespace.node if isinstance(A,NodeSource)else E),]=E
					if len(D)>=O:break
				else:W.append(A)
			if W and len(D)<O:
				C.add_edges_from((x:=[(A,o)for A in W]),weight=Y)
				for M in itertools.islice(nx.shortest_simple_paths(C,n,o,weight=m),O-len(D)):
					M=M[1:-1];X=[]
					for k in range(0,len(M)-1,2):y,l,z=cast('tuple[CallEdgeSource, ast.AST, CallEdgeSource]',M[k:k+3]);X.append(j(y,l,C.edges[l,z]['confidence']))
					assert X;D[tuple(X)]=E
				C.remove_edges_from(x)
			assert D;F[B]=_B,list(D)
	return F
def _split_ap_options(ap):return[A.strip()for A in(ap[1:-1].split(',')if ap.startswith('{')else[ap])]
def _find_access_path_matches(a,access_path):
	D='()';B=access_path;assert B;G,E=B.split(' ')
	if G=='call':E+=D
	C,*H=E.split('.');assert C.startswith('<')and C.endswith('>'),f"Invalid import access path: {B}";I=_split_ap_options(C[1:-1])
	if not(A:=[(A,A.module_identifier)for A in a.module_access_paths if any(fnmatch(A.module_identifier,B)for B in I)]):return
	for F in H:
		if(J:=F.rstrip(D)):
			K=_split_ap_options(J)
			if not(A:=[C for A in{A for(A,B)in A}for B in K for C in a.read_access_paths.get((A,B),())]):return
		for L in range(F.count(D)):
			if not(A:=[B for A in{A for(A,B)in A}for B in a.call_access_paths.get(A,())]):return
	return{A for(B,A)in A}
def is_access_path_vuln(vuln_path):return vuln_path.startswith(('import ','read ','call '))