from __future__ import annotations
_A=None
import ast,logging
from typing import TYPE_CHECKING,Final,TypeAlias,assert_type,cast,final
import networkx as nx
from typing_extensions import override
from.bindings import BindingMixin,DeclInfo,ResolvableNode,ResolvedName,ResolvedNames,is_load
from.cfg import CFG,Block,Branch,CFGBuilder,Jump,SplitClass
if TYPE_CHECKING:from collections.abc import Iterator,Mapping,Sequence,Set;from mambalade.diagnostics import Diagnostics;from.transform import BoolEval
logger=logging.getLogger(__name__)
def rename_to_single_assignment(fun,declarations,beval,resolved_names,d):
	E=resolved_names;A={B for(B,A)in declarations.items()if not A.jump_to_global and not A.constant and not A.captured}
	if not A:d.rename_no_candidates+=1;return
	C=CFGBuilder(fun,beval).build();K,F,L=_UsesVisitor(C,A,E).get_uses();d.rename_unrenamable+=len(F);A.difference_update(F)
	if not A:d.rename_no_candidates_2+=1;return
	d.rename_success+=1;d.rename_variables+=len(A);M,N=_dominator_tree(C);G={}
	for H in A:
		I=set();J=L[H];D=list(J)
		while D:
			for B in N[D.pop()]:
				if B in I:continue
				I.add(B);G.setdefault(B,{})[H]=[]
				if B not in J:D.append(B)
	_do_renaming(C,E,A,K,M,G,d)
def _dominator_tree(cfg):
	A=cfg;B=nx.DiGraph();B.add_node(A.entry);B.add_edges_from((A,B)for A in A.blocks for B in A.edges());C=cast('dict[Block, Block]',nx.immediate_dominators(B,A.entry));E={A:set[Block]()for A in C}
	for(F,I)in C.items():
		if len((J:=B.pred[F]))>=2:
			for D in J:
				while D!=I:E[D].add(F);D=C[D]
	G={}
	for(H,K)in C.items():
		if H is not A.entry:G.setdefault(K,[]).append(H)
	return G,E
_Use=tuple[str,ResolvableNode]
_Uses=_Use|list[_Use]
@final
class _UsesVisitor(BindingMixin):
	def __init__(A,cfg,to_rename,resolved_names):A.cfg=cfg;A.to_rename=to_rename;A.resolved_names=resolved_names;A.block_uses={};A.current_block=cfg.entry;A.current_vars=[];A.unrenamable=set();A.unorderable_nodes=0;A.unorderable=_A
	def get_uses(A):
		E=A.cfg.function.args
		for Q in(E.posonlyargs,E.args,E.kwonlyargs):
			for F in Q:A.visit(F)
		for F in(E.vararg,E.kwarg):
			if F is not _A:A.visit(F)
		for C in A.cfg.blocks:
			A.current_block=C;A.block_uses[C]=A.current_vars
			for H in C.stmts:
				match H:
					case Jump():pass
					case Branch(N):
						if N is not _A:A.visit(N)
					case SplitClass(R):A.visit_ClassDef(R)
					case _:assert_type(H,ast.stmt);A.visit(H)
			A.current_vars=[]
		G={A:set()for A in A.to_rename};I=dict.fromkeys(A.to_rename,0)
		for(C,J)in A.block_uses.items():
			for D in J:
				match D:
					case list(J):
						O=set()
						for(B,K)in J:
							if not is_load(K)and B not in O:O.add(B);I[B]+=1;G[B].add(C)
					case B,K:
						if not is_load(K):I[B]+=2;G[B].add(C)
		L=[]
		for(B,P)in I.items():
			if P==0:L.append(B);A.unrenamable.add(B)
			elif P==1:A.unrenamable.add(B)
		if L:logger.error("Not all variables are assigned in the function '%s' (missing %s)",A.cfg.function.name,L)
		if A.unrenamable:
			for B in A.unrenamable:del G[B]
			for(C,vars)in A.block_uses.items():
				M=[]
				for D in vars:
					if type(D)is list:
						if(S:=[B for B in D if B[0]not in A.unrenamable]):M.append(S)
					elif D[0]not in A.unrenamable:M.append(D)
				A.block_uses[C]=M
		return A.block_uses,A.unrenamable,G
	@override
	def handle_binding(self,node,name):
		A=self
		if name in A.to_rename:
			B=A.resolved_names[node];assert B is not _A
			if B.ns is A.cfg.function:(C if(C:=A.unorderable)is not _A else A.current_vars).append((name,node))
	def _push_unorderable(A):
		if A.unorderable_nodes==0:A.unorderable=[]
		A.unorderable_nodes+=1
	def _pop_unorderable(A):
		A.unorderable_nodes-=1
		if A.unorderable_nodes==0:
			if A.unorderable:A.current_vars.append(A.unorderable)
			A.unorderable=_A
	@override
	def visit(self,node):
		B=node;A=self
		match B:
			case ast.arg():pass
			case ast.arguments():
				for D in(B.defaults,B.kw_defaults):
					for E in D:
						if E is not _A:A.visit(E)
			case ast.FunctionDef()|ast.AsyncFunctionDef():
				for E in B.decorator_list:A.visit(E)
				A.visit(B.args)
				if B.returns is not _A:A.visit(B.returns)
			case ast.Lambda():A.visit(B.args)
			case ast.Name(id,ctx=ast.Load()):A.handle_binding(B,id)
			case ast.AugAssign(ast.Name(id,ctx=ast.Store())as C):
				if id in A.to_rename:
					H=A.resolved_names[C];assert H is not _A
					if H.ns is A.cfg.function:A.unrenamable.add(id)
				A.visit(B.value)
			case ast.IfExp():A.visit(B.test);A._push_unorderable();A.visit(B.body);A.visit(B.orelse);A._pop_unorderable()
			case ast.BoolOp(values=[I,*J]):
				A.visit(I);A._push_unorderable()
				for F in J:A.visit(F)
				A._pop_unorderable()
			case ast.With()|ast.AsyncWith():
				for K in B.items:A.visit(K)
				A._push_unorderable()
				for G in B.body:A.visit(G)
				A._pop_unorderable()
			case ast.Try()|ast.TryStar():A._push_unorderable();A.generic_visit(B);A._pop_unorderable()
			case ast.Match():
				A.visit(B.subject);A._push_unorderable()
				for L in B.cases:A.visit(L)
				A._pop_unorderable()
			case ast.NamedExpr(C,F):A.visit(F);A.handle_binding(C,C.id)
			case ast.Assign():
				A.visit(B.value)
				for C in B.targets:A.visit(C)
			case ast.AnnAssign():
				if B.value is not _A:A.visit(B.value)
				A.visit(B.target);A.visit(B.annotation)
			case ast.For()|ast.AsyncFor():
				A.visit(B.iter);A.visit(B.target)
				for D in(B.body,B.orelse):
					for G in D:A.visit(G)
			case ast.ClassDef():
				for D in(B.decorator_list,B.bases,B.body):
					for M in D:A.visit(M)
			case ast.comprehension():
				A.visit(B.iter)
				for N in B.ifs:A.visit(N)
				A.visit(B.target)
			case _:A.generic_visit(B)
		if(O:=getattr(A,f"visit_{type(B).__name__}",_A))is not _A:O(B)
def _do_renaming(cfg,resolved_names,to_rename,block_vars,dom_tree,phis_to_add,d):
	R=phis_to_add;Q=dom_tree;P=to_rename;E=resolved_names;K=cfg.function;S=dict.fromkeys(P,0);F={A:[]for A in P};C=set();L={}
	def G(id,record_use=False):
		A=F[id]
		while A:
			B,D=A[-1]
			if D not in I:A.pop();continue
			if B is not _A and record_use:C.add(B.name)
			return B
	def M(name):A=name;B=S[A]=S[A]+1;return ResolvedName(K,f"{A}${B}",_A)
	def T(block):
		D=block
		if(H:=R.get(D))is not _A:
			for(A,I)in H.items():C=M(A);L[C.name]=A,C,I;F[A].append((C,D))
		for N in block_vars.get(D,()):
			match N:
				case list(J):
					K=set()
					for(A,B)in J:
						if(not isinstance(B,ast.Name)or isinstance(B.ctx,ast.Store))and A not in K:
							K.add(A);C=M(A)
							if(O:=G(A))is not _A:L[C.name]=A,C,[O]
							F[A].append((C,D))
					for(A,B)in J:
						if isinstance(B,ast.Name)and isinstance(B.ctx,ast.Del):continue
						E[B]=G(A,record_use=is_load(B))
				case A,ast.Name(ctx=ast.Load())as B:E[B]=G(A,record_use=True)
				case A,ast.Name(ctx=ast.Del()):F[A].append((_A,D))
				case A,B:
					if isinstance(B,ast.arg):C=E[B];assert C is not _A
					else:C=E[B]=M(A)
					F[A].append((C,D))
		for P in D.edges():
			if(H:=R.get(P))is _A:continue
			for(A,I)in H.items():
				if(Q:=G(A))is not _A:I.append(Q)
	D=cfg.entry;H=[(D,iter(Q.get(D,())))];I={D};T(D)
	while H:
		W,X=H[-1]
		try:A=next(X)
		except StopIteration:H.pop();I.remove(W)
		else:
			I.add(A);T(A)
			if(Y:=Q.get(A))is not _A:H.append((A,iter(Y)))
			else:I.remove(A)
	U=list(C)
	for Z in U:
		if(a:=L.get(Z))is not _A:
			V,b,c=a;N=[]
			for J in c:
				B=ast.Name(V,ast.Load());E[B]=J;N.append(B)
				if J.name not in C:C.add(J.name);U.append(J.name)
			B=ast.Name(V,ast.Store());E[B]=b;O=ast.Assign([B],ast.BoolOp(ast.Or(),N));ast.copy_location(O,K);ast.fix_missing_locations(O);K.body.insert(0,O);d.rename_phis+=1
			if len(N)==1:d.rename_trivial_phis+=1