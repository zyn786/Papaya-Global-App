from __future__ import annotations
import logging
from typing import TYPE_CHECKING
from mambalade.natives.builtin_functions import strict_identity_decorator
from mambalade.natives.helpers import native_function,unsupported_native
from mambalade.natives.property import Property
from mambalade.tokens import NativeToken,Token
from mambalade.vars import ConstraintVar
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.calls import CallData;from mambalade.operations import Operations
logger=logging.getLogger(__name__)
@native_function('functools.lru_cache',spec='lambda maxsize=128, typed=False: 0')
def lru_cache(op,d):
	A=d.args
	if A.kwargs or A.num_definite_pos_args in(0,2):op.return_value(d,strict_identity_decorator)
	elif isinstance((B:=A.args[0]),Token|ConstraintVar):op.return_value(d,B)
@native_function('functools.wraps',spec='lambda wrapped, assigned=None, updated=None: 0')
def wraps(op,d):
	A=d.args
	if A.kwargs:op.a.warn_unsupported(d.callnode,'functools.wraps with kwargs')
	if A.num_definite_pos_args>1:op.a.warn_unsupported(d.callnode,'functools.wraps with assigned or updated')
	op.return_value(d,strict_identity_decorator)
@native_function('functools.update_wrapper',spec='lambda wrapper, wrapped, assigned=None, updated=None: 0')
def update_wrapper(op,d):
	A=op;B=d.args
	if B.kwargs:
		for(C,D)in B.kwargs:
			match C:
				case'wrapper':
					if isinstance(D,Token|ConstraintVar):A.return_value(d,D)
				case'assigned':A.a.warn_unsupported(d.callnode,'functools.update_wrapper with assigned')
				case'updated':A.a.warn_unsupported(d.callnode,'functools.update_wrapper with updated')
				case'wrapped':pass
				case None:A.a.warn_unsupported(d.callnode,'functools.update_wrapper with kwarg unpacking')
				case _:raise AssertionError(f"Unexpected kwarg name: {C!r}")
	if B.num_definite_pos_args>2:A.a.warn_unsupported(d.callnode,'functools.update_wrapper with assigned or updated')
	if B.args and isinstance((E:=B.args[0]),Token|ConstraintVar):A.return_value(d,E)
model={'cache':strict_identity_decorator,'lru_cache':lru_cache,'cached_property':Property,'wraps':wraps,'update_wrapper':update_wrapper,'partial':unsupported_native('functools.partial',lambda op,d:op.invoke_unknown(d)),'total_ordering':strict_identity_decorator}