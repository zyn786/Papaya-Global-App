from __future__ import annotations
from collections import Counter,defaultdict
from contextlib import contextmanager
from datetime import datetime,timedelta
from typing import TYPE_CHECKING,Final,Literal,TypeAlias,final
if TYPE_CHECKING:from collections.abc import MutableMapping
TimingKey=Literal['parsing','constraint_setup','patching','preanalysis','propagation','vuln_analysis','vuln_paths']
TransformKey=Literal['attrs_to_dataclasses','add_metaclass','with_metaclass','if']
@final
class Diagnostics:
	def __init__(A):A.start=datetime.now();A.timed_out=False;A.timings=defaultdict(timedelta);A.transforms=Counter[TransformKey]();A.failed_mro_linearizations=0;A.failed_relative_imports=0;A.patched_app_imports=0;A.patched_empty_vars=0;A.patched_self_args=0;A.patched_cls_args=0;A.patched_unreachable_functions=0;A.worklist_rounds=0;A.code_size=0;A.call_edges=0;A.dispatch_normal=0;A.dispatch_normal_incompatible=0;A.dispatch_native=0;A.dispatch_native_compatible=0;A.rename_no_candidates=0;A.rename_no_candidates_2=0;A.rename_success=0;A.rename_variables=0;A.rename_unrenamable=0;A.rename_phis=0;A.rename_trivial_phis=0
	@contextmanager
	def time(self,key):
		A=datetime.now()
		try:yield
		finally:self.timings[key]+=datetime.now()-A