from __future__ import annotations
_A=True
from typing import TYPE_CHECKING
from mambalade.natives.builtin_functions import strict_identity_decorator
from mambalade.natives.core import Object,Type
from mambalade.natives.helpers import NativeType,native_type
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.tokens import NativeToken
@native_type(Type,Object,tname='enum.EnumType',mark_unsupported=_A)
class EnumType(NativeType):0
@native_type(Object,tname='enum.Enum',mark_unsupported=_A)
class Enum(NativeType):0
@native_type(Enum,Object,tname='enum.ReprEnum',mark_unsupported=_A)
class ReprEnum(NativeType):0
@native_type(ReprEnum,Enum,Object,tname='enum.IntEnum',mark_unsupported=_A)
class IntEnum(NativeType):0
@native_type(ReprEnum,Enum,Object,tname='enum.StrEnum',mark_unsupported=_A)
class StrEnum(NativeType):0
@native_type(Enum,Object,tname='enum.Flag',mark_unsupported=_A)
class Flag(NativeType):0
@native_type(ReprEnum,Flag,Enum,Object,tname='enum.IntFlag',mark_unsupported=_A)
class IntFlag(NativeType):0
model={'EnumType':EnumType,'Enum':Enum,'ReprEnum':ReprEnum,'IntEnum':IntEnum,'StrEnum':StrEnum,'Flag':Flag,'IntFlag':IntFlag,'unique':strict_identity_decorator,'global_enum':strict_identity_decorator}