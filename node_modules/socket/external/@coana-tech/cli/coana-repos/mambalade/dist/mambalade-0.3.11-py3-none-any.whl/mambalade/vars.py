from __future__ import annotations
import ast
from abc import abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING,Final,Generic,final
from typing_extensions import TypeVar,dataclass_transform
from.asthelpers import str_ast
from.infos import NamespaceNode
from.typing import TypeABC
if TYPE_CHECKING:from.asthelpers import FunctionNode;from.contexts import Context;from.infos import QualifiedNode,SynthProp;from.tokens import ObjectToken
class ConstraintVar(TypeABC):
	__slots__=()
	@abstractmethod
	def __str__(self):...
	@final
	def __repr__(self):return str(self)
_NT=TypeVar('_NT',bound=ast.AST,default=ast.AST,infer_variance=True)
_T=TypeVar('_T',bound=ConstraintVar)
_dc=dataclass(slots=True,repr=False,unsafe_hash=True)
@dataclass_transform()
def constraintvar(A):assert issubclass(A,ConstraintVar);return _dc(A)
@constraintvar
class NodeVar(ConstraintVar,Generic[_NT]):
	node:Final[_NT];context:Final[Context]
	def __str__(A):return f"{type(A).__name__}[{str_ast(A.node)}] @ {A.context}"
@final
@constraintvar
class ReturnVar(ConstraintVar):
	fun:Final[QualifiedNode[FunctionNode]];context:Final[Context]
	def __str__(A):return f"ReturnVar[{A.fun}] @ {A.context}"
@final
@constraintvar
class DecoratorResultVar(NodeVar[ast.expr]):0
@final
@constraintvar
class ForIterElemVar(NodeVar[ast.For|ast.AsyncFor|ast.comprehension]):0
@final
@constraintvar
class NamespaceVar(NodeVar[NamespaceNode]):
	prop:Final[str]
	def __str__(A):return f"NamespaceVar[{str_ast(A.node)}.{A.prop}] @ {A.context}"
@final
@constraintvar
class MapInputVar(NodeVar):
	index:Final[int]
	def __str__(A):return f"MapInputVar[{str_ast(A.node)}][{A.index}] @ {A.context}"
@final
@constraintvar
class MaxElementsVar(NodeVar):0
@final
@constraintvar
class FilterInputVar(NodeVar):0
@final
@constraintvar
class KwargsUnpackVar(NodeVar[ast.Call]):0
@final
@constraintvar
class PropVar(ConstraintVar):
	obj:Final[ObjectToken];prop:Final[str|SynthProp]
	def __str__(A):return f"PropVar[{A.obj}.{A.prop}]"
@final
@constraintvar
class SeqIndexVar(ConstraintVar):
	seq:Final[ObjectToken];index:Final[int]
	def __str__(A):return f"SeqIndexVar[{A.seq}[{A.index}]]"
@final
@constraintvar
class DictKeyVar(ConstraintVar):
	dict:Final[ObjectToken];key:Final[str]
	def __str__(A):return f"DictKeyVar[{A.dict}[{A.key}]]"
@final
@constraintvar
class AttributeVar(ConstraintVar):
	base:Final[ConstraintVar];attr:Final[str]
	def __str__(A):return f"{A.base}.[{A.attr}]"
@final
@constraintvar
class SubscriptVar(ConstraintVar):
	base:Final[ConstraintVar];index:Final[int|str|ConstraintVar|None]
	def __str__(A):return f"{A.base}[{A.index}]"