from __future__ import annotations
_B=False
_A=None
from abc import abstractmethod
from typing import TYPE_CHECKING,Final,TypeAlias,final,overload
from typing_extensions import override
from.typing import TypeABC
from.util import CacheHashMixin,Singleton,is_dunder
from.vars import PropVar
if TYPE_CHECKING:import ast;from collections.abc import Callable;from.accesspathmanager import AccessPath;from.calls import CallData;from.contexts import Context;from.infos import ClassInfo,Native,QualifiedNode;from.natives.core_tokens import NativeTypeToken;from.operations import Operations;from.vars import ConstraintVar;NativeFunctionImpl=Callable[[Operations,CallData],_A]
class _TokenBase(TypeABC):
	@abstractmethod
	def __str__(self):...
	@abstractmethod
	def __eq__(A,B):...
	@final
	def __repr__(self):return str(self)
	@abstractmethod
	def __hash__(self):...
_LookupResult=tuple['Token | ConstraintVar | None',bool]
class ObjectToken(_TokenBase):
	__match_args__='typ',;typ:TypeToken;immutable:bool
	@final
	def lookup_attr(self,attr):
		if attr=='__class__':return self.typ,True
		return self._lookup_attr(attr)
	@abstractmethod
	def _lookup_attr(A,B):...
class TypeToken(ObjectToken):
	mro:tuple[TypeToken,...];user_defined:QualifiedNode[ast.ClassDef]|_A
	@abstractmethod
	def new_instance(A,B,C):0
class NativeToken(ObjectToken):
	immutable=True;__match_args__='kind',
	@override
	def __init__(self,kind):super().__init__();self.kind=kind
	@override
	@final
	def __eq__(self,other):A=other;return isinstance(A,NativeToken)and self.kind==A.kind
	@override
	@final
	def __str__(self):return f"{type(self).__name__}({self.kind})"
	@override
	@final
	def __hash__(self):return hash(self.kind)
class MROLinearizationError(Exception):0
def class_lookup_attr(B,C,A):
	D=A in C.definite_declarations
	if is_dunder(A):
		if A in C.declarations:return PropVar(B,A),D
		return _A,_B
	return PropVar(B,A),_B
@final
class ClassToken(TypeToken,CacheHashMixin):
	immutable=_B;__match_args__='cls',
	@override
	def __init__(self,cls,bases,info,typ):A=self;super().__init__();A.cls=cls;A.bases=bases;A.info=info;A.typ=typ;A.compute_mro()
	@property
	def user_defined(self):return self.cls
	@override
	def __str__(self):return f"ClassToken({self.cls})"
	@override
	def __eq__(self,other):A=other;return isinstance(A,ClassToken)and(self.cls,self.bases)==(A.cls,A.bases)
	@override
	def _compute_hash(self):return hash((self.cls,self.bases))
	def compute_mro(A):
		B=A.bases;assert B
		if len(B)==1:A.mro=A,*B[0].mro
		else:
			E=[A];C=[list(A.mro)for A in B]+[list(B)]
			while C:
				for F in C:
					D=F[0]
					if all(D not in A[1:]for A in C):E.append(D);C=[A for A in[A if A[0]!=D else A[1:]for A in C]if A];break
				else:raise MROLinearizationError(f"Cannot linearize MRO for {A} with bases {B} (stuck on {C})")
			A.mro=tuple(E)
	@override
	def _lookup_attr(A,B):return class_lookup_attr(A,A.info,B)
	@override
	def new_instance(A,B=_A,C=_A):return InstanceToken(A)
def class_token(site,bases,info):from.natives.core import Type;return ClassToken(site,bases,info,Type)
@final
class InstanceToken(ObjectToken,CacheHashMixin):
	immutable=_B
	@override
	def __init__(self,typ):super().__init__();assert typ.user_defined is not _A;self.typ=typ
	@override
	def __str__(self):return f"InstanceToken({self.typ})"
	@override
	def __eq__(self,other):A=other;return isinstance(A,InstanceToken)and self.typ==A.typ
	@override
	def _compute_hash(self):return hash((type(self),self.typ))
	@override
	def _lookup_attr(self,attr):return PropVar(self,attr),_B
@final
class ImmutableToken(ObjectToken,CacheHashMixin):
	immutable=True;__match_args__='site','typ'
	@overload
	def __init__(self,site,typ,context=_A):...
	@overload
	def __init__(self,site,typ,context=_A):...
	@override
	def __init__(self,site,typ,context=_A):A=self;super().__init__();A.site=site;A.typ=typ;A.context=context
	@override
	def __str__(self):A=self;return f"ImmutableToken({A.site}, {A.typ}){f" @ {A.context}"if A.context else""}"
	@override
	def __eq__(self,other):B=self;A=other;return isinstance(A,ImmutableToken)and(B.site,B.typ,B.context)==(A.site,A.typ,A.context)
	@override
	def _compute_hash(self):A=self;return hash((type(A),A.site,A.typ,A.context))
	@override
	def _lookup_attr(self,attr):return _A,_B
@final
class UnknownToken(Singleton,_TokenBase):
	__slots__=()
	@override
	def __str__(self):return'UnknownToken'
@final
class AccessPathToken(_TokenBase,CacheHashMixin):
	__match_args__='access_path',
	def __init__(A,access_path):super().__init__();A.access_path=access_path
	def __str__(A):return f"AccessPathToken({A.access_path})"
	def __eq__(B,A):return isinstance(A,AccessPathToken)and B.access_path==A.access_path
	def _compute_hash(A):return hash((type(A),A.access_path))
if TYPE_CHECKING:Token=ObjectToken|UnknownToken|AccessPathToken
else:Token=_TokenBase