from __future__ import annotations
import ast,logging
from typing import TYPE_CHECKING
from mambalade import graph
from mambalade.infos import ClassInfo,reachable_contexts
from mambalade.vars import ConstraintVar,DecoratorResultVar,NodeVar
if TYPE_CHECKING:from collections.abc import Sequence;from mambalade.globalstate import EmptyVarError;from mambalade.solver import Solver
logger=logging.getLogger(__name__)
def resolve_empty_var_errors(solver,var,msgs):
	B=solver;B.global_state.diagnostics.patched_empty_vars+=1;logger.warning('Variable %s is unexpectedly empty:\n%s',var,'\n'.join(f"  {B} at {A}"for(A,B,C)in msgs))
	for(C,C,A)in msgs:
		if callable(A):A()
		else:B.add_token_constraint(A,var)
def patch_empty_vars(solver):
	K='patching';C=solver;B=C.global_state
	if not B.error_if_empty:return
	with B.diagnostics.time(K):
		D=C._subset_edges;F=[A for A in D if type(A)is NodeVar]
		for E in B.node_info.values():
			if isinstance(E,ClassInfo)and(L:=E.node.node.decorator_list):F.extend(G for A in reachable_contexts(E.parent_fun)if(G:=DecoratorResultVar(L[0],A))in D and C.empty_or_only_unknown(G))
		M=graph.transitive_closure(D.get,F);H=[[]for A in range(3)]
		for A in B.error_if_empty:
			if type(A)is NodeVar and isinstance(A.node,ast.ClassDef):round=2
			elif A in M:round=1
			else:round=0
			H[round].append(A)
	for(round,vars)in enumerate(H,start=1):
		if not vars:continue
		I=False
		with B.diagnostics.time(K):
			for A in vars:
				J=B.error_if_empty.pop(A);assert J
				if not C.empty_or_only_unknown(A):continue
				I=True;resolve_empty_var_errors(C,A,J)
		if I:
			logger.info('Re-propagating after patching empty vars (round %d)',round)
			with B.diagnostics.time('propagation'):C.propagate()