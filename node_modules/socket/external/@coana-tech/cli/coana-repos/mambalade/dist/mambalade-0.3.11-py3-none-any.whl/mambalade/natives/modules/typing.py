from __future__ import annotations
_B='typing.NewType'
_A='__new__'
import logging
from typing import TYPE_CHECKING,Final
from mambalade.infos import Native
from mambalade.natives import Dict,Object
from mambalade.natives._namedtuple import NamedTuple
from mambalade.natives.builtin_functions import noop,strict_identity_decorator
from mambalade.natives.helpers import NativeType,generic_class_getitem,native_function,native_method,native_type
from mambalade.tokens import ImmutableToken,NativeToken,Token
from mambalade.vars import ConstraintVar
logger=logging.getLogger(__name__)
if TYPE_CHECKING:from collections.abc import Mapping;from mambalade.calls import CallData;from mambalade.operations import Operations
@native_function('typing.cast',spec='lambda typ, val: 0')
def cast(op,d):
	A=d.args
	if A.kwargs:op.a.warn_unsupported(d.callnode,'typing.cast with kwargs')
	elif A.unpack_iter is not None:op.a.warn_unsupported(d.callnode,'typing.cast with *args')
	elif isinstance((B:=A.args[1]),Token|ConstraintVar):op.return_value(d,B)
@native_function('typing.assert_type',spec='lambda val, typ, /: 1')
def assert_type(op,d):
	if isinstance((A:=d.args.args[0]),Token|ConstraintVar):op.return_value(d,A)
@native_type(Object,tname='typing.Generic',mark_unsupported=True)
class Generic(NativeType):__class_getitem__=generic_class_getitem
@native_type(Generic,Object,tname='typing.Protocol',unsupported_methods=('__subclasshook__',))
class Protocol(NativeType):__new__=noop
@native_type(Object,tname=_B)
class NewType(NativeType):
	@native_method(_A,spec='lambda cls, name, type: 1')
	@staticmethod
	def new(op,d):
		if d.args.args[0]is NewType:op.return_value(d,_newtype_singleton)
		else:Object.call_slot(_A,op,d)
	@native_method('__call__',spec='lambda self, value, /: 2')
	@staticmethod
	def call(op,d):
		if isinstance((A:=d.args.args[1]),Token|ConstraintVar):op.return_value(d,A)
_newtype_singleton=ImmutableToken(Native(_B),NewType)
model={'overload':noop,'override':strict_identity_decorator,'final':strict_identity_decorator,'runtime_checkable':strict_identity_decorator,'no_type_check':strict_identity_decorator,'no_type_check_decorator':strict_identity_decorator,'cast':cast,'assert_type':assert_type,'NamedTuple':NamedTuple,'NewType':NewType,'TypedDict':Dict,'Generic':Generic,'Protocol':Protocol}