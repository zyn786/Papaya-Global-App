from __future__ import annotations
_B=False
_A=None
import logging
from dataclasses import dataclass,field
from datetime import datetime
from typing import TYPE_CHECKING,Final,final
from.infos import ModuleInfo,ModuleKind,SynthProp
from.natives.module import ModuleToken
from.natives.modules import NativeModuleImporter
from.tokens import Token,UnknownToken
from.tokenset import TokenSet,TokenSetImpl
from.util import dfield
from.vars import ConstraintVar,DictKeyVar,PropVar,SeqIndexVar
if TYPE_CHECKING:from collections import defaultdict;from collections.abc import Callable,Iterable,Set;from.globalstate import GlobalState;from.listeners import ListenerKey
logger=logging.getLogger(__name__)
@final
@dataclass(slots=True)
class Solver:
	global_state:Final[GlobalState];_tokens:Final[defaultdict[ConstraintVar,TokenSet]]=dfield(TokenSetImpl);_unprocessed_tokens:Final[defaultdict[ConstraintVar,TokenSet]]=dfield(TokenSetImpl);_subset_edges:Final[defaultdict[ConstraintVar,set[ConstraintVar]]]=dfield(set);_listeners:Final[defaultdict[ConstraintVar,dict[ListenerKey,Callable[[Token],_A]]]]=dfield(dict);_listeners_processed:Final[defaultdict[ListenerKey,TokenSet]]=dfield(TokenSetImpl);_module_props:Final[defaultdict[ModuleToken,set[str]]]=dfield(set);_module_props_listeners:Final[defaultdict[ModuleToken,dict[ListenerKey,Callable[[str],_A]]]]=dfield(dict);_iterations:int=field(default=0,init=_B);_last_progress:datetime=field(default_factory=datetime.now,init=_B)
	def __post_init__(B):C=NativeModuleImporter().find_spec('builtins',_A);assert C is not _A;A=ModuleInfo(C,ModuleKind.NATIVE);B.global_state.modules[A.name]=A;B.global_state.worklist.append(A)
	def __repr__(A):return f"{type(A).__name__}()"
	def add_token_constraint(A,token,var):
		if var is not _A:A._add_token(token,var)
	def _add_token(A,token,var):
		B=token
		if(C:=A._tokens.get(var))is _A or B not in C:A._unprocessed_tokens[var].add(B)
	def _add_tokens(A,tokens,var):
		C=var;B=tokens
		if not B:return
		if(F:=A._tokens.get(C))is _A:A._unprocessed_tokens[C].update(B)
		else:
			D=_A
			for E in B:
				if E not in F:
					if D is _A:D=A._unprocessed_tokens[C]
					D.add(E)
	def add_subset_constraint(C,frm,to):
		B=frm;A=to
		if B is _A or A is _A or B==A:return
		D=C._subset_edges[B]
		if A not in D:D.add(A);C._add_tokens(C._tokens.get(B,()),A)
	def add_forall_constraint(A,var,key,listener):
		D=listener;C=key;B=var
		if isinstance(B,Token):A._run_listener(C,D,(B,))
		else:
			E=A._listeners[B]
			if C not in E:
				E[C]=D
				if(F:=A._tokens.get(B)):A._run_listener(C,D,F)
	def add_forall_props_constraint(A,module,key,listener):
		C=listener;B=module;D=A._module_props_listeners[B]
		if key not in D:
			D[key]=C
			for E in A._module_props.get(B,()):C(E)
	def _run_listener(C,key,listener,ts):
		B=C._listeners_processed[key]
		for A in ts:
			if A not in B:B.add(A);listener(A)
	def _increment_iterations(A):
		A._iterations+=1
		if A._iterations&63==0 and((B:=A.global_state).options.timeout or B.options.progress_interval):
			C=datetime.now()
			if(D:=B.options.timeout)and C-B.diagnostics.start>=D:B.diagnostics.timed_out=True;raise TimeoutError
			if(E:=B.options.progress_interval)and C-A._last_progress>=E:A._last_progress=C;logger.info('Solver progress: %d iterations, %d unprocessed variables, %d worklist items, %d call edges',A._iterations,len(A._unprocessed_tokens),len(B.worklist),B.diagnostics.call_edges)
	def _on_first_token(B,var):
		A=var
		if isinstance(A,PropVar):
			if isinstance(A.prop,str):
				if isinstance((C:=A.obj),ModuleToken):
					D=B._module_props[C];assert A.prop not in D;D.add(A.prop)
					for E in B._module_props_listeners.get(C,{}).values():E(A.prop)
			elif A.prop==SynthProp.SEQ_UNKNOWN:B.add_subset_constraint(A,PropVar(A.obj,SynthProp.SEQ_ALL))
			elif A.prop==SynthProp.DICT_VAL_UNKNOWN:B.add_subset_constraint(A,PropVar(A.obj,SynthProp.DICT_VAL_ALL))
		elif isinstance(A,SeqIndexVar):B.add_subset_constraint(A,PropVar(A.seq,SynthProp.SEQ_ALL))
		elif isinstance(A,DictKeyVar):B.add_subset_constraint(A,PropVar(A.dict,SynthProp.DICT_VAL_ALL))
	def propagate(A):
		while A._unprocessed_tokens:
			A._increment_iterations();B,C=A._unprocessed_tokens.popitem();assert C;D=A._tokens[B]
			if not D:A._on_first_token(B)
			D.update(C)
			for E in A._subset_edges.get(B,()):A._add_tokens(C,E)
			if(F:=A._listeners.get(B)):
				for(G,H)in tuple(F.items()):A._run_listener(G,H,C)
	def num_tokens(A,var):return len(A._tokens.get(var,()))+len(A._unprocessed_tokens.get(var,()))
	def get_tokens(B,var,*,include_unprocessed=_B):
		A=B._tokens.get(var,TokenSetImpl())
		if include_unprocessed and(C:=B._unprocessed_tokens.get(var))is not _A:A=TokenSetImpl(A);A.update(C)
		return A
	def empty_or_only_unknown(A,var,*,include_unprocessed=_B):return _empty(A._tokens.get(var))and(not include_unprocessed or _empty(A._unprocessed_tokens.get(var)))
	def all_vars(A):return A._tokens.keys()|A._listeners.keys()|A._subset_edges.keys()
def _empty(ts):return not ts or len(ts)==1 and next(iter(ts))is UnknownToken()
class TimeoutError(Exception):0