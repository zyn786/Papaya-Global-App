from __future__ import annotations
import functools,re,sys
from abc import abstractmethod
from collections import defaultdict
from dataclasses import field
from enum import Enum
from typing import TYPE_CHECKING,Any,ClassVar,TypeVar,final
from.typing import TypeABC
if TYPE_CHECKING:from collections.abc import Callable,Hashable,Iterable;from typing import Self
def compile_module_regex(modules):return re.compile(f"(?:{"|".join(map(re.escape,modules))})\\b")
_stdlib_pat=compile_module_regex(sys.stdlib_module_names)
def is_stdlib_module(module):return bool(_stdlib_pat.match(module))
def is_dunder(name):A=name;return A.startswith('__')and A.endswith('__')and len(A)>4
class TVL(Enum):
	FALSE=0;MAYBE=1;TRUE=2
	@classmethod
	def of(A,value):return TVL.TRUE if value else TVL.FALSE
	def __invert__(A):
		if A is TVL.FALSE:return TVL.TRUE
		if A is TVL.TRUE:return TVL.FALSE
		return TVL.MAYBE
class Singleton:
	__slots__=();_instance:ClassVar[Self]
	@final
	def __new__(cls):return cls._instance
	@classmethod
	def __init_subclass__(A):super().__init_subclass__();A._instance=super().__new__(A);A._instance.__init__()
	__eq__=object.__eq__;__hash__=object.__hash__
_missing=object()
_P=TypeVar('_P',bound='Hashable')
_R=TypeVar('_R')
def simple_cache(func):
	C={}
	@functools.wraps(func)
	def A(arg):
		A=arg
		if(B:=C.get(A,_missing))is not _missing:return B
		B=C[A]=func(A);return B
	return A
_K=TypeVar('_K')
_T=TypeVar('_T')
def dfield(factory):return field(default_factory=lambda:defaultdict(factory),init=False)
class CacheHashMixin(TypeABC):
	def __init__(A):super().__init__();A._hash=None
	@abstractmethod
	def _compute_hash(self):...
	@final
	def _hash_impl(self):
		A=self
		if(B:=A._hash)is None:A._hash=B=A._compute_hash()
		return B
	@classmethod
	def __init_subclass__(A,**B):super().__init_subclass__(**B);A.__hash__=A._hash_impl