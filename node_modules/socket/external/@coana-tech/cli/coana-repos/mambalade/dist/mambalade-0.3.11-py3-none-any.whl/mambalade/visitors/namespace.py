from __future__ import annotations
_C='globals'
_B='builtins'
_A=None
import ast
from typing import TYPE_CHECKING,Final,Literal,Protocol,TypeAlias,final
from typing_extensions import override
from mambalade.infos import NamespaceNode
Namespace=NamespaceNode|Literal[_B,_C]
if TYPE_CHECKING:
	from collections.abc import Callable,Hashable,Iterator
	def _(x):return x
	class BoundVisitor(Protocol):
		__self__:NamespaceVisitor;__func__:Callable[[ast.AST],bool|_A]
		def __call__(A,node):...
@final
class ScopeChain:
	__slots__='depth','ns','parent'
	def __init__(A,ns,parent=_A):B=parent;A.ns=ns;A.parent=B;A.depth=1 if B is _A else B.depth+1
	def __iter__(B):
		A=B
		while True:
			yield A.ns
			if A.parent is _A:break
			A=A.parent
	def __len__(A):return A.depth
_root_builtins=ScopeChain(_B)
_root_globals=ScopeChain(_C,_root_builtins)
class NamespaceVisitor(ast.NodeVisitor):
	__slots__='scopes',
	def __init__(A):A.scopes=_root_builtins
	@property
	def scope(self):return self.scopes.ns
	@final
	def _push_scope(self,ns):self.scopes=ScopeChain(ns,self.scopes)
	@final
	def _pop_scope(self):A=self.scopes.parent;assert A is not _A;self.scopes=A
	@final
	def _args_outside(self,node):
		A=node
		def C(node):
			if node is not _A:self.visit(node)
		for D in A.posonlyargs+A.args+A.kwonlyargs:C(D.annotation)
		for B in A.defaults:self.visit(B)
		for B in A.kw_defaults:C(B)
	@final
	def _args_inside(self,node):
		C=self;A=node;C._visit_nonrecursive(A)
		for B in A.posonlyargs+A.args+A.kwonlyargs:C._visit_nonrecursive(B)
		for B in(A.vararg,A.kwarg):
			if B is not _A:C._visit_nonrecursive(B)
	@final
	@override
	def generic_visit(self,node):raise ValueError('This function should not be called')
	@final
	def _visit_nonrecursive(self,node):
		A=getattr(self,f"visit_{type(node).__name__}",_A)
		if A is not _A:A(node)
	@final
	@override
	def visit(self,node):
		B=self;A=node;C=getattr(B,f"visit_{type(A).__name__}",_A)
		match A:
			case ast.FunctionDef()|ast.AsyncFunctionDef():
				F=C is not _A and C(A);B._args_outside(A.args)
				for D in A.decorator_list:B.visit(D)
				if A.returns is not _A:B.visit(A.returns)
				if not F:
					B._push_scope(A);B._args_inside(A.args)
					for D in A.body:B.visit(D)
					B._pop_scope()
			case ast.Lambda():
				F=C is not _A and C(A);B._args_outside(A.args)
				if not F:B._push_scope(A);B._args_inside(A.args);B.visit(A.body);B._pop_scope()
			case ast.ClassDef():
				if C is not _A:C(A)
				for D in A.decorator_list+A.bases+A.keywords:B.visit(D)
				B._push_scope(A)
				for D in A.body:B.visit(D)
				B._pop_scope()
			case ast.Module():
				if C is not _A:C(A)
				B.scopes=_root_globals;super().generic_visit(A);B._pop_scope()
			case ast.ListComp()|ast.SetComp()|ast.DictComp()|ast.GeneratorExp():
				E=A.generators[0];B.visit(E.iter)
				if C is not _A:C(A)
				B._push_scope(A);B._visit_nonrecursive(E);B.visit(E.target)
				for G in E.ifs+A.generators[1:]:B.visit(G)
				if isinstance(A,ast.DictComp):B.visit(A.key);B.visit(A.value)
				else:B.visit(A.elt)
				B._pop_scope()
			case ast.Constant():
				if C is not _A and C.__func__ is not ast.NodeVisitor.visit_Constant:C(A)
				super().generic_visit(A)
			case _:
				if C is not _A:C(A)
				super().generic_visit(A)