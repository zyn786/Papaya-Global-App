from __future__ import annotations
import logging
from typing import TYPE_CHECKING,ParamSpec,cast
if TYPE_CHECKING:from collections.abc import Callable
logger=logging.getLogger()
def _noop(*A,**B):0
LogP=ParamSpec('LogP')
def logf(level):
	def A(f):
		if logger.isEnabledFor(level):return f
		return cast('Callable[LogP, None]',_noop)
	return A