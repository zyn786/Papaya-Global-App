from __future__ import annotations
import logging
from typing import TYPE_CHECKING,Final
from.infos import ModuleIdentifier
if TYPE_CHECKING:from collections.abc import Iterable;from pathlib import Path
logger=logging.getLogger(__name__)
def find_test_files(path):return[A for A in path.rglob('*.py')if A.is_file()and(A.stem.startswith('test_')or A.stem.endswith('_test')or A.stem=='conftest')]
class _TreeNode:
	def __init__(A,path):A.path=path;A.has_init=(path/'__init__.py').is_file();A.children={}
	def child(A,name):
		B=name
		if B not in A.children:A.children[B]=_TreeNode(A.path/B)
		return A.children[B]
def transform_files_to_input(paths,root):
	J='.';B=root;assert B.is_dir();K=[];F={};L=_TreeNode(B)
	for C in paths:
		assert C.is_file()and C.is_relative_to(B);A=list(C.with_suffix('').relative_to(B).parts);G=A.pop()
		if J in G:logger.error('Ignoring file with dots in its name: %s',C);continue
		D=L
		for(H,I)in reversed([*enumerate(A)]):
			if J in I:
				H+=1
				for M in A[:H]:D=D.child(M)
				A=A[H:];break
		E=D
		for(N,I)in enumerate(A):
			E=E.child(I)
			if E.has_init:F[E.path.parent.resolve(strict=True)]=None;A=A[N:];break
		else:F[D.path.resolve(strict=True)]=None
		if G!='__init__'or not A:A.append(G)
		K.append(ModuleIdentifier(J.join(A)))
	return K,list(F)