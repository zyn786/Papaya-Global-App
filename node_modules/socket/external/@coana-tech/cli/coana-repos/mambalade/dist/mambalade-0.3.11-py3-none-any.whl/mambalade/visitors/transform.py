from __future__ import annotations
_D='metaclass'
_C=False
_B=None
_A=True
import ast
from dataclasses import dataclass
from typing import TYPE_CHECKING,ClassVar,Final,Literal,NamedTuple,TypeGuard,assert_type,final
from typing_extensions import override
from mambalade.infos import FunctionInfo,ModuleKind
from mambalade.util import TVL
from.bindings import ResolvedName,ResolvedNames
if TYPE_CHECKING:from mambalade.diagnostics import Diagnostics
def _with_metaclass(cls,d):
	match cls.bases:
		case[ast.Call(ast.Name('with_metaclass')|ast.Attribute(_,'with_metaclass'),[meta,*bases],[])]if not isinstance(meta,ast.Starred):cls.keywords.append(ast.keyword(_D,meta));cls.bases=bases;d.transforms['with_metaclass']+=1;return _A
		case _:return
def _add_metaclass(cls,d):
	match cls.decorator_list:
		case[ast.Call(ast.Name('add_metaclass')|ast.Attribute(_,'add_metaclass'),[meta],[])as cn]if not isinstance(meta,ast.Starred):cls.lineno=cn.lineno;cls.decorator_list.clear();cls.keywords.append(ast.keyword(_D,meta));d.transforms['add_metaclass']+=1;return _A
		case _:return
def _attrs_to_dataclasses(cls,d,resolved_names):
	C='default_factory';B='dataclass';A='dataclasses'
	def _name(name,ns):n=ast.Name(name,ast.Load());resolved_names[n]=ResolvedName(ns,name,_B);return n
	for(i,dec)in enumerate(cls.decorator_list):
		match dec.func if isinstance(dec,ast.Call)else dec:
			case ast.Attribute(ast.Name('attr'),'s'|'attrs'|'dataclass')as callee:
				new_dec=ast.Attribute(value=ast.Call(func=_name('__import__','builtins'),args=[ast.Constant(A)],keywords=[]),attr=B,ctx=ast.Load());ast.copy_location(new_dec,callee);ast.fix_missing_locations(new_dec)
				if isinstance(dec,ast.Call):
					dec.func=new_dec;is_auto_attribs=_C
					for(j,kw)in enumerate(dec.keywords):
						if kw.arg=='auto_attribs':
							if isinstance((c:=kw.value),ast.Constant)and isinstance(c.value,bool):is_auto_attribs=c.value
							else:is_auto_attribs=_A
							dec.keywords.pop(j);break
				else:cls.decorator_list[i]=new_dec;is_auto_attribs=callee.attr==B
				break
			case _:pass
	else:return
	d.transforms['attrs_to_dataclasses']+=1
	def t_field(node):
		match node:
			case ast.Call(ast.Attribute(ast.Name('attr'),'ib'|'attrib'|'field')|ast.Attribute(ast.Name('attrs'),'field')):
				new_func=ast.Attribute(value=_name(A,'globals'),attr='field',ctx=ast.Load());ast.copy_location(new_func,node.func);ast.fix_missing_locations(new_func);node.func=new_func
				for kw in node.keywords:
					if kw.arg=='factory':kw.arg=C;break
				return _A
			case _:return _C
	field_map={}
	for(i,stmt)in enumerate(cls.body):
		match stmt:
			case ast.Assign([ast.Name()as target],value)if not is_auto_attribs and t_field(value):new_assign=ast.AnnAssign(target=target,annotation=ast.Constant('Any'),value=value,simple=1);ast.copy_location(new_assign,stmt);cls.body[i]=new_assign;field_map[target.id]=value
			case ast.AnnAssign(ast.Name(name),_,value,simple=1)if t_field(value):field_map[name]=value
			case ast.FunctionDef(fname,args,decorator_list=[ast.Attribute(ast.Name(field),'default')as dec])if(fv:=field_map.get(field))is not _B:
				stmt.lineno=dec.lineno;stmt.decorator_list.clear();nkw=ast.keyword(C,_name(fname,cls));ast.copy_location(nkw,dec);ast.fix_missing_locations(nkw);fv.keywords.append(nkw)
				if len(args.posonlyargs)+len(args.args)==1 and not args.defaults:args.defaults=[ast.Constant(_B)]
			case _:pass
def t_ClassDef(cls,d,resolved_names):
	if not any(kw.arg==_D for kw in cls.keywords)and(_with_metaclass(cls,d)or _add_metaclass(cls,d)):return
	_attrs_to_dataclasses(cls,d,resolved_names)
class _VersionInfo(NamedTuple):major:int;minor:int;micro:int;releaselevel:str;serial:int
@final
@dataclass(frozen=_A,slots=_A)
class _SysWithVersionInfo:version_info:_VersionInfo
@final
@dataclass(slots=_A)
class BoolEval:
	module_kind:Final[ModuleKind]=ModuleKind.APP
	@staticmethod
	def is_sys_versioninfo(node,*,allow_access=_A):
		match node:
			case ast.Attribute(ast.Name('sys',ast.Load()),'version_info'):return _A
			case ast.Subscript(n,ast.Constant()|ast.Slice())|ast.Attribute(n)if allow_access:return BoolEval.is_sys_versioninfo(n,allow_access=_C)
			case _:return _C
	@staticmethod
	def is_literal(node):
		try:ast.literal_eval(node);return _A
		except(ValueError,TypeError):return _C
	_version_info_low:ClassVar[Final]=_SysWithVersionInfo(_VersionInfo(3,7,0,'alpha',0));_version_info_high:ClassVar[Final]=_SysWithVersionInfo(_VersionInfo(3,1000,1000,'final',1000))
	def eval(self,node):
		B='__builtins__';A='sys'
		match node:
			case ast.Name('TYPE_CHECKING')|ast.Attribute(_,'TYPE_CHECKING'):return TVL.FALSE
			case ast.Compare(ast.Name('__name__'),[ast.Eq()],[ast.Constant('__main__')]):return TVL.FALSE if self.module_kind is not ModuleKind.APP else TVL.MAYBE
			case ast.Compare(lhs,[_],[rhs])if self.is_sys_versioninfo(lhs)and self.is_literal(rhs):
				try:code=compile(ast.Expression(node),'<string>','eval',dont_inherit=_A,optimize=0);b1=TVL.of(eval(code,{A:self._version_info_low,B:_B}));b2=TVL.of(eval(code,{A:self._version_info_high,B:_B}));return b1 if b1 is b2 else TVL.MAYBE
				except Exception:return TVL.MAYBE
			case ast.BoolOp(ast.And(),values):
				res=TVL.TRUE
				for v in values:
					if(bv:=self.eval(v))is TVL.FALSE:return bv
					elif bv is TVL.MAYBE:res=bv
				return res
			case ast.BoolOp(ast.Or(),values):
				res=TVL.FALSE
				for v in values:
					if(bv:=self.eval(v))is TVL.TRUE:return bv
					elif bv is TVL.MAYBE:res=bv
				return res
			case ast.Constant(value):return TVL.of(value)
			case ast.UnaryOp(ast.Not(),lhs):return~self.eval(lhs)
			case _:return TVL.MAYBE
def t_If(stmt,beval,d):
	if(bv:=beval.eval(stmt.test))is TVL.MAYBE:return
	d.transforms['if']+=1;(stmt.body if bv is TVL.FALSE else stmt.orelse)[:]=ast.Pass(),
@final
class TransformVisitor(ast.NodeVisitor):
	def __init__(self,beval,d,resolved_names):self.beval=beval;self.d=d;self.resolved_names=resolved_names
	@override
	def visit(self,node):
		match node:
			case ast.expr():return
			case ast.ClassDef():t_ClassDef(node,self.d,self.resolved_names)
			case ast.If():t_If(node,self.beval,self.d)
			case _:pass
		self.generic_visit(node)
@final
class ConstantReturnRemover(ast.NodeVisitor):
	def __init__(self,info):self.info=info;decls=info.declarations;self.constant_params={p for p in info.params.all_parameter_names()if decls[p].constant}
	def _transform_exp(self,node):
		match node:
			case ast.Name(id,ctx=ast.Load())if id in self.constant_params:
				if(rcp:=self.info.returned_constant_params)is _B:self.info.returned_constant_params={id}
				else:rcp.add(id)
				return
			case ast.BoolOp(_,values):
				nvalues=[e for v in values if(e:=self._transform_exp(v))]
				if len(nvalues)<len(values):
					if not nvalues:return
					node.values=nvalues
			case ast.IfExp(_,body,orelse):
				if(nb:=self._transform_exp(body))is not body:node.body=nb or ast.Constant(_B)
				if(ne:=self._transform_exp(orelse))is not orelse:node.orelse=ne or ast.Constant(_B)
			case _:pass
		return node
	def transform(self):
		if self.constant_params and not self.info.generator:
			if isinstance((node:=self.info.node.node),ast.Lambda):
				if(nb:=self._transform_exp(node.body))is not node.body:node.body=nb or ast.Constant(_B)
			elif isinstance(node,ast.FunctionDef):
				for stmt in node.body:self.visit(stmt)
			else:assert_type(node,ast.AsyncFunctionDef)
	@override
	def visit(self,node):
		match node:
			case ast.Return(value)if value is not _B:
				if(nv:=self._transform_exp(value))is not value:node.value=nv
			case ast.expr()|ast.ClassDef()|ast.FunctionDef()|ast.AsyncFunctionDef():return
			case _:self.generic_visit(node)