from __future__ import annotations
_D='lambda obj, attr, /: 2'
_C='__getattribute__'
_B='__new__'
_A=None
import ast,logging
from dataclasses import replace
from typing import TYPE_CHECKING,assert_type
from mambalade.calls import AbstractArgs,CallData
from mambalade.listeners import Listener,ListenerKey
from mambalade.token_utils import lookup_attr_mro,lookup_attr_mro2
from mambalade.tokens import AccessPathToken,ObjectToken,Token,TypeToken,UnknownToken
from mambalade.vars import ConstraintVar,PropVar
from.core_tokens import NativeFunctionToken,NativeTypeToken
from.helpers import NativeType,native_method,native_type
if TYPE_CHECKING:from mambalade.operations import Operations
logger=logging.getLogger(__name__)
def object_getattribute(op,d,obj,attr):
	B=attr;A=obj;C,D=A.lookup_attr(B)
	if C is not _A:op.return_value(d,C)
	E,G=lookup_attr_mro2(A.typ,B)
	if E:
		F=ListenerKey(Listener.NATIVE_OBJECT__GETATTRIBUTE__,token=A,string=B,parent=d.parent);H=op.descr_handler(A,A.typ,replace(d,parent=F),data_only=D)
		for I in E:op.solver.add_forall_constraint(I,F,H)
	return D or G
def type_getattribute(op,d,obj,attr):
	B=attr;A=obj;C,D=lookup_attr_mro2(A,B);E,H=lookup_attr_mro2(A.typ,B)
	if E:
		F=ListenerKey(Listener.NATIVE_TYPE__GETATTRIBUTE__1,token=A,string=B,parent=d.parent);I=op.descr_handler(A,A.typ,replace(d,parent=F),data_only=D)
		for J in E:op.solver.add_forall_constraint(J,F,I)
	if C:
		G=ListenerKey(Listener.NATIVE_TYPE__GETATTRIBUTE__2,token=A,string=B,parent=d.parent);K=op.descr_handler(_A,A,replace(d,parent=G))
		for L in C:op.solver.add_forall_constraint(L,G,K)
	return D or H
@native_type()
class Object(NativeType):
	@native_method(_B,supports_kwargs=True)
	@staticmethod
	def new(op,d):
		A=op;B=d.args
		if not B.args:
			if B.unpack_iter is not _A:A.a.warn_unsupported(d.callnode,'Iterable unpacking in object.__new__')
			logger.debug('Discarding invalid call to object.__new__ with no arguments');return
		C,*E=B.args
		if isinstance(C,Token|ConstraintVar):
			def D(ct):
				B=ct
				match B:
					case NativeTypeToken():
						if B is Type:A.a.warn_unsupported(d.callnode,'Dynamic class creation')
						elif not B.supports_instantiation():A.a.warn_unsupported(d.callnode,f"Instantiation of native type '{B.kind.name}'")
						else:A.return_value(d,B.new_instance(A,d))
					case TypeToken():A.return_value(d,B.new_instance(A,d))
					case UnknownToken():A.return_value(d,B)
					case AccessPathToken():pass
					case _:assert_type(B,ObjectToken);A.a.warn_unsupported(d.callnode,f"Non-type token in object.__new__: {type(B)}")
			A.forall_constraint_uncached(C,ListenerKey(Listener.NATIVE_OBJECT__NEW__,parent=d.parent),D)
	@native_method(_C,spec=_D)
	@staticmethod
	def getattribute(op,d):
		A,B=d.args.args
		if isinstance(A,ConstraintVar):op.a.warn_unsupported(d.callnode,'object.__getattribute__ on non-constant token');return
		assert isinstance(A,ObjectToken)
		if not isinstance(B,str):op.a.warn_unsupported(d.callnode,'object.__getattribute__ with non-constant attribute name');op.return_value(d,UnknownToken());return
		object_getattribute(op,d,A,B)
	@native_method('__setattr__',spec='lambda self, name, value, /: 3')
	@staticmethod
	def setattr(op,d):
		A=op;D,B,C=d.args.args
		if not isinstance(D,Token|ConstraintVar):logger.debug('Discarding invalid call to object.__setattr__ with non-token object');return
		if not isinstance(B,str):A.a.warn_unsupported(d.callnode,'object.__setattr__ with non-constant attribute name');return
		if B=='__class__':A.a.warn_unsupported(d.callnode,'Assignment to the __class__ attribute');return
		def E(t):
			if not isinstance(t,ObjectToken):logger.debug('Ignoring object.__setattr__ for non-object token %s',t);return
			if not t.immutable and isinstance(C,Token|ConstraintVar):A.inclusion_constraint(C,PropVar(t,B))
			if(D:=lookup_attr_mro(t.typ,B)):
				E=ListenerKey(Listener.NATIVE_OBJECT__SETATTR__SET,token=t,parent=d.parent);F=replace(d,args=AbstractArgs.seq(t,C),res=_A,parent=E)
				for G in D:A.invoke_special_method(G,'__set__',F)
		A.forall_constraint_uncached(D,ListenerKey(Listener.NATIVE_OBJECT__SETATTR__,parent=d.parent),E)
@native_type(Object)
class Type(NativeType):
	@native_method(_C,spec=_D)
	@staticmethod
	def getattribute(op,d):
		A=op;B,C=d.args.args
		match B:
			case TypeToken():pass
			case ConstraintVar():A.a.warn_unsupported(d.callnode,'type.__getattribute__ on non-constant token');return
			case ObjectToken()|UnknownToken()|AccessPathToken():logger.debug('Discarding invalid call to type.__getattribute__ with non-type object: %s',B);return
			case str()|int()|ast.Slice()|None:A.a.warn_unsupported(d.callnode,'type.__getattribute__ on non-token');return
		if not isinstance(C,str):A.a.warn_unsupported(d.callnode,'type.__getattribute__ with non-constant attribute name');A.return_value(d,UnknownToken());return
		type_getattribute(A,d,B,C)
	@native_method('__call__',spec='lambda cls, /, *args, **kwargs: 1')
	@staticmethod
	def call(op,d):
		A=op;E=d.args;B,*C=E.args
		if not isinstance(B,Token):A.a.warn_unsupported(d.callnode,'type.__call__ on non-constant token');return
		if B==Type:
			if len(C)==1 and not E.kwargs:
				A.a.register_native_call(d.caller,d.callnode.node,Type.kind)
				if d.res is not _A and isinstance((G:=C[0]),Token|ConstraintVar):
					def H(t):
						match t:
							case ObjectToken(B):A.return_value(d,B)
							case UnknownToken():A.return_value(d,t)
							case AccessPathToken():pass
					A.solver.add_forall_constraint(G,ListenerKey(Listener.NATIVE_TYPE_TYPEOF,parent=d.parent),H)
				return
			if len(C)!=3:logger.debug('Discarding invalid call to type(...) with %d arguments',len(C));return
		if not isinstance(B,TypeToken):A.a.warn_unsupported(d.callnode,f"Non-type token in type.__call__: {type(B)}");return
		if isinstance(B,NativeTypeToken):A.a.register_native_call(d.caller,d.callnode.node,B.kind)
		D,I=B.lookup_attr(_B);F=[D]if D is not _A else[]
		if D is _A or not I:F+=[A for A in lookup_attr_mro(B,_B)if isinstance(A,NativeFunctionToken)]or[Object.known_slots[_B]]
		J=ListenerKey(Listener.NATIVE_TYPE__CALL__MAYBE_INIT,parent=d.parent);K=replace(d,args=d.args.shift(),res=_A,parent=ListenerKey(Listener.NATIVE_TYPE__CALL__INIT,parent=d.parent))
		def L(t):A.return_value(d,t);A.forall_constraint_uncached(t,J,M)
		def M(t):
			match t:
				case ObjectToken(C)if B in C.mro:A.invoke_special_method(t,'__init__',K)
				case _:pass
		N=ListenerKey(Listener.NATIVE_TYPE__CALL__NEW,parent=d.parent);O=replace(d,res=L,parent=N)
		for P in F:A.invoke_object(P,O)
NativeTypeToken.typ=Type