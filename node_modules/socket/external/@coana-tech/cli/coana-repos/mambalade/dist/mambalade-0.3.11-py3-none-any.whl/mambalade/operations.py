from __future__ import annotations
_E='__get__'
_D='__getitem__'
_C=False
_B=True
_A=None
import ast,logging
from dataclasses import replace
from fnmatch import fnmatch
from pathlib import Path
from typing import TYPE_CHECKING,Final,LiteralString,assert_type,final
from.import util
from.accesspathmanager import CallAccessPath,ImportAccessPath
from.calls import AbstractArg,AbstractArgs,CallData,MatchResult,ResultHandler,may_args_match_params
from.contexts import CompoundContext,Context,EmptyContext
from.infos import CallEdgeKind,CallEdgeSource,FunctionInfo,ModuleIdentifier,ModuleInfo,ModuleKind,NodeSource,QualifiedNode,SynthProp,source_module
from.listeners import Listener,ListenerKey
from.natives import Coroutine,Dict,Generator,List,Tuple
from.natives.core_tokens import NativeFunctionSpec,NativeFunctionToken
from.natives.dict import UnpackedDictToken
from.natives.functions import AsyncGenerator,BoundMethodToken,FunctionToken,StaticMethod
from.natives.iterator import IteratorToken
from.natives.module import ModuleToken
from.natives.sequences import EmptyTupleToken,seq_iter
from.options import ContextSensitivity
from.token_utils import lookup_attr_mro,type_has_attr
from.tokens import AccessPathToken,ImmutableToken,ObjectToken,Token,TypeToken,UnknownToken
from.util import TVL
from.vars import ConstraintVar,DictKeyVar,KwargsUnpackVar,NamespaceVar,PropVar,ReturnVar,SeqIndexVar
from.visitors.bindings import Free
if TYPE_CHECKING:from collections.abc import Callable,Collection,Set;from.asthelpers import FunctionNode;from.imports import Importer;from.solver import Solver
logger=logging.getLogger(__name__)
def is_decorator_call(key):
	A=key
	if A.listener==Listener.CALL_DECORATOR:return _B
	elif A.parent is _A:return _C
	else:return is_decorator_call(A.parent)
@final
class Operations:
	__slots__='_cached_escaping_reachability_handler','a','importer','solver'
	def __init__(A,solver,importer):B=solver;A.solver=B;A.a=B.global_state;A.importer=importer;A._cached_escaping_reachability_handler=A._escaping_reachability_handler
	def inclusion_constraint(A,a,b):
		match a:
			case None:pass
			case ConstraintVar():A.solver.add_subset_constraint(a,b)
			case _:A.solver.add_token_constraint(a,b)
	def forall_constraint_uncached(C,var,key,listener):
		B=listener;A=var
		if isinstance(A,Token):B(A)
		else:C.solver.add_forall_constraint(A,key,B)
	def _iterable_elem(B,iter,A,index_hint=_A):
		F='__iter__';C=index_hint
		match iter:
			case EmptyTupleToken():pass
			case IteratorToken(_,G):B.return_value(A,G)
			case ObjectToken(D):
				E=ListenerKey(Listener.OP_ITERABLE_ELEM,number=C,parent=A.parent)
				if any(A in(List,Tuple)for A in D.mro)and lookup_attr_mro(D,F)==[seq_iter]:assert C is _A or C>=0;B.invoke_special_method(iter,_D,replace(A,args=AbstractArgs.seq(C),parent=E))
				elif type_has_attr(D,F)is not TVL.FALSE:H=ListenerKey(Listener.OP_ITERABLE_ELEM_NEXT,parent=E);I=replace(A,args=AbstractArgs.empty,parent=H);B.invoke_special_method(iter,F,replace(A,args=AbstractArgs.empty,res=lambda iter:B.invoke_special_method(iter,'__next__',I),parent=ListenerKey(Listener.OP_ITERABLE_ELEM_ITER,parent=E)))
			case AccessPathToken():pass
			case UnknownToken():B.return_value(A,iter)
	def unpack_iterable_into(A,iterables,d):B=replace(d,parent=ListenerKey(Listener.OP_UNPACK_ITERABLE_ELEM,parent=d.parent));A.forall_constraint_uncached(iterables,B.parent,lambda it:A._iterable_elem(it,B))
	def unpack_iterable_into_vars(A,prefix_vs,rest_v,iterables,callnode,caller,parent):
		E=caller;D=callnode;C=rest_v;B=ListenerKey(Listener.OP_UNPACK_ITERABLE,parent=parent)
		def F(t):
			if C is not _A:A._iterable_elem(t,CallData(AbstractArgs.empty,C,D,E,B))
			for(G,F)in enumerate(prefix_vs):
				if F is not _A:A._iterable_elem(t,CallData(AbstractArgs.empty,F,D,E,B),index_hint=G)
		A.forall_constraint_uncached(iterables,B,F)
	def awaitt(B,awaitable,d):
		A=awaitable
		if A is not _A:
			if d.parent.listener not in(Listener.AWAIT,Listener.ASYNC_FOR_AWAIT):d=replace(d,args=AbstractArgs.empty,parent=ListenerKey(Listener.OP_AWAIT,parent=d.parent))
			else:assert d.args is AbstractArgs.empty
			B.invoke_special_method(A,'__await__',d)
	def descr_handler(B,obj,owner,d,*,data_only=_C):
		def A(descr):
			A=descr
			if not isinstance(A,ObjectToken):B.return_value(d,A);return
			if data_only and type_has_attr(A.typ,'__set__')is TVL.FALSE and type_has_attr(A.typ,'__delete__')is TVL.FALSE:return
			match lookup_attr_mro(A.typ,_E):
				case[ObjectToken()as C]:D=ListenerKey(Listener.OP_DESCR_HANDLER,token=A,parent=d.parent);B.invoke_object(C,replace(d,args=AbstractArgs.seq(A,obj,owner),parent=D))
				case[]:B.return_value(d,A)
				case _:B.a.warn_unsupported(d.callnode,'Non-definite descriptor');B.return_value(d,A)
		return A
	def _new_context(G,d,fun_context,info):
		B=fun_context
		if not G.a.options.context_sensitivity.need_freevars():return EmptyContext()
		C=d.callnode if G.a.options.context_sensitivity is ContextSensitivity.CS1 else _A;A=_A
		if is_decorator_call(d.parent):C=A=d.callnode
		elif isinstance((D:=d.context),CompoundContext)and D.decorator_node and D.decorator_node==D.callnode:C=d.callnode;A=D.decorator_node
		H=B if isinstance(B,CompoundContext)and B.decorator_node and B.decorator_node!=A else _A;E=CompoundContext.constant_params
		if not isinstance((J:=info.node.node),ast.Lambda)and J.name in(_D,'__setitem__','__setattr__','__getattribute__'):
			F=[]
			for(K,I)in zip(info.params.params,d.args.args,strict=_C):
				if isinstance(I,str):F.append((K.name,I))
			if F:E=tuple(sorted(F))
		return EmptyContext()if C is _A and A is _A and H is _A and not E else CompoundContext(callnode=C,decorator_node=A,decorator_context=H,constant_params=E)
	@staticmethod
	def _vararg_token(fun,vararg,new_context):return ImmutableToken(fun.replace(vararg),Tuple,new_context)
	@staticmethod
	def _kwarg_token(fun,kwarg,new_context):return ImmutableToken(fun.replace(kwarg),Dict,new_context)
	def _dispatch_call(A,callee,d):
		g='Incompatible call %s -> %s: %s';J=callee;logger.debug('Dispatching call %s = %s\n          with: %s',d.res,J,d.args)
		match J:
			case FunctionToken(B,T):
				A.a.diagnostics.dispatch_normal+=1;I=A.a.function_info[B.node];C=d.args;E=B.node.args;G=I.params
				match may_args_match_params(C,G):
					case MatchResult(U,K,V):pass
					case H,C:
						A.a.diagnostics.dispatch_normal_incompatible+=1
						if logger.isEnabledFor(logging.DEBUG):logger.debug(g,d.callnode,B,H%C)
						return
				F=A._new_context(d,T,I);A.a.register_call_edge(d.caller,d.callnode.node,NodeSource(B,F));W=isinstance(B.node,ast.AsyncFunctionDef)
				if I.generator:L=ImmutableToken(B,AsyncGenerator if W else Generator)
				elif W:L=ImmutableToken(B,Coroutine);A.solver.add_subset_constraint(ReturnVar(B,F),PropVar(L,SynthProp.COROUTINE_ELEMENT))
				else:L=ReturnVar(B,F)
				A.return_value(d,L);M=I.returned_constant_params
				def N(arg,param):
					D=param;C=arg
					if isinstance(C,Token|ConstraintVar):
						A.inclusion_constraint(C,NamespaceVar(B.node,F,D))
						if M is not _A and D in M:A.return_value(d,C)
				O=min(K,len(C.args))
				for(D,P)in zip(C.args[:O],G.params[:O],strict=_B):N(D,P.name)
				X=G.params[O:K]
				if X or E.vararg is not _A and K==len(G.params):
					if E.vararg is not _A and K==len(G.params):
						Y=A._vararg_token(B,E.vararg,F);Z=PropVar(Y,SynthProp.SEQ_UNKNOWN)
						for(h,D)in enumerate(C.args[O:]):
							if isinstance(D,Token|ConstraintVar):A.inclusion_constraint(D,SeqIndexVar(Y,h))
					else:Z=_A
					if C.unpack_iter is not _A:
						a=[]
						for P in X:b=NamespaceVar(B.node,F,P.name);a.append(b if M is _A or P.name not in M else lambda t,v=b:(A.inclusion_constraint(t,v),A.return_value(d,t))[1])
						A.unpack_iterable_into_vars(a,Z,C.unpack_iter,d.callnode,d.caller,ListenerKey(Listener.OP_CALL_POS_UNPACK,(B.node,F),parent=d.parent))
				if C.kwargs is not _A:
					c=E.kwarg and A._kwarg_token(B,E.kwarg,F);S=G.param_by_name.keys()-U if A.a.options.model_mapping_unpacking and V else _A
					for i in C.kwargs:
						match i:
							case None,KwargsUnpackVar()as D:
								if E.kwarg is not _A:A.solver.add_subset_constraint(D,NamespaceVar(B.node,F,E.kwarg.arg))
								if not S:continue
								def j(t):
									match t:
										case UnknownToken():
											for A in S:N(t,A)
										case UnpackedDictToken(B):
											for A in S:N(DictKeyVar(B,A),A)
										case _:raise AssertionError(f"Unexpected token {t}")
								A.solver.add_forall_constraint(D,ListenerKey(Listener.OP_CALL_KWARGS_UNPACK,(B.node,F),parent=d.parent),j)
							case None,_:assert not A.a.options.model_mapping_unpacking
							case Q,D if G.valid_kw_arg(Q):N(D,Q)
							case Q,D:
								assert c is not _A
								if isinstance(D,Token|ConstraintVar):A.inclusion_constraint(D,DictKeyVar(c,Q))
				A.make_function_reachable(I,T,F,U,V,d.res)
			case NativeFunctionToken(R):
				A.a.diagnostics.dispatch_native+=1
				match J.spec:
					case None:pass
					case NativeFunctionSpec(E,e):
						if E.kwarg is _A and not E.param_by_name and d.args.kwargs:logger.debug('Incompatible call %s -> %s that does not support kwargs',d.callnode,R);return
						match may_args_match_params(d.args,E):
							case MatchResult():pass
							case H,C:
								if logger.isEnabledFor(logging.DEBUG):logger.debug(g,d.callnode,R,H%C)
								return
						if len(d.args.args)<e:
							if d.args.unpack_iter is not _A:H=f"{R.name} with iterable unpacking"
							else:assert d.args.kwargs is not _A;H=f"{R.name} with too few known positional arguments ({len(d.args.args)} < {e})"
							A.a.warn_unsupported(d.callnode,H);return
				A.a.diagnostics.dispatch_native_compatible+=1;J.impl(A,d)
			case UnknownToken():A.invoke_unknown(d)
			case AccessPathToken(k):f=CallAccessPath(d.callnode);A.a.access_paths_manager.add_call_access_path(f,k,d.caller);A.return_value(d,AccessPathToken(f))
	def make_function_reachable(A,info,closure_context,new_context,param_filled,has_kw_unpack,result_handler=_A):
		J=param_filled;I=closure_context;D=new_context;B=info
		if D not in B.reachable_contexts:B.reachable_contexts.add(D);A.a.worklist.append((B,D))
		def G(name):return NamespaceVar(F.node,D,name)
		F=B.node;C=F.node.args
		if(K:=C.vararg)is not _A:A.solver.add_token_constraint(A._vararg_token(F,K,D),G(K.arg))
		if(L:=C.kwarg)is not _A:A.solver.add_token_constraint(A._kwarg_token(F,L,D),G(L.arg))
		if not C.defaults and not any(C.kw_defaults)and not B.free_variables:return
		M=A.a.modules[F.module].visitor;assert M is not _A;N=B.returned_constant_params
		def O(default,param):
			B=param
			if(C:=M.get_var(default,context=I))is _A:return
			A.solver.add_subset_constraint(C,G(B))
			if N is not _A and B in N:A._into_handler(result_handler,C)
		if C.defaults:
			T=B.params
			for(E,H)in zip(T.params[-len(C.defaults):],C.defaults,strict=_B):
				assert E.has_default
				if E.name not in J:O(H,E.name)
		for(E,H)in zip(C.kwonlyargs,C.kw_defaults,strict=_B):
			if E.arg not in J:
				if H is not _A:O(H,E.arg)
				else:assert has_kw_unpack
		if B.free_variables:
			assert B.parent is not _A
			for(P,(Q,U))in B.free_variables.items():
				R=NamespaceVar(U,I,P);S=G(P)
				if Free.READ in Q:A.solver.add_subset_constraint(R,S)
				if Free.WRITE in Q:A.solver.add_subset_constraint(S,R)
	def invoke_object(B,obj,d):
		def E(ft,key):
			A=key
			while A is not _A:
				if A.listener==Listener.OP_INVOKE and A.token==ft:return _B
				A=A.parent
			return _C
		def A(ft):
			A=ft
			match A:
				case FunctionToken()|NativeFunctionToken()|AccessPathToken()|UnknownToken():B._dispatch_call(A,d)
				case BoundMethodToken(F,D):C=ListenerKey(Listener.OP_BOUND_METHOD,token=D,parent=d.parent);B.invoke_object(F,replace(d,args=d.args.prepend(D),parent=C))
				case _ if not E(A,d.parent):C=ListenerKey(Listener.OP_INVOKE,token=A,parent=d.parent);B.invoke_special_method(A,'__call__',replace(d,parent=C))
				case _:assert_type(A,ObjectToken);logger.debug('Breaking infinite recursion in __call__ to %s',A)
		B.forall_constraint_uncached(obj,d.parent,A)
	def invoke_special_method(A,objs,name,d):
		B=name
		def D(t,key):
			A=key
			while A is not _A:
				if A.listener==Listener.OP_SPECIAL_METHOD and A.token==t and A.string==B:return _B
				A=A.parent
			return _C
		def C(t):
			match t:
				case ObjectToken(E)if not D(t,d.parent):
					if(F:=lookup_attr_mro(E,B)):
						C=ListenerKey(Listener.OP_SPECIAL_METHOD,token=t,string=B,parent=d.parent);G=replace(d,parent=C)
						def H(ft):
							B=ft
							match B:
								case FunctionToken()|NativeFunctionToken():A._dispatch_call(B,replace(d,args=d.args.prepend(t),parent=C))
								case _:
									if isinstance(B,ObjectToken)and B.typ is not StaticMethod and type_has_attr(B.typ,_E)is not TVL.FALSE:A.a.warn_unsupported(d.callnode,'Descriptor protocol for special methods')
									A.invoke_object(B,G)
						for I in F:A.forall_constraint_uncached(I,C,H)
				case UnknownToken():A.invoke_unknown(d)
				case AccessPathToken():pass
				case _:assert_type(t,ObjectToken);logger.debug("Breaking infinite recursion in special method dispatch for '%s' on %s",B,t)
		A.forall_constraint_uncached(objs,d.parent,C)
	def return_value(A,d,value):A._into_handler(d.res,value)
	def _into_handler(C,h,value):
		B=value
		match h:
			case None:pass
			case ConstraintVar()as A:C.inclusion_constraint(B,A)
			case A:A(B)
	def _escaping_reachability_handler(A,t):
		if(D:=_find_escaping_fun(t))is _A:return
		E=EmptyContext();B=D.fun;C=B.node.args
		for F in(*C.posonlyargs,*C.args,*C.kwonlyargs):A.solver.add_token_constraint(UnknownToken(),NamespaceVar(B.node,E,F.arg))
		A.make_function_reachable(A.a.function_info[B.node],D.context,E,param_filled=set(),has_kw_unpack=_B)
	def register_escaping(A,var,d):
		B=EmptyContext()
		def C(t):
			if(C:=_find_escaping_fun(t))is not _A:A.a.register_call_edge(d.caller,d.callnode.node,NodeSource(C.fun,B),kind=CallEdgeKind.ESCAPED)
		A.solver.add_forall_constraint(var,ListenerKey(Listener.ESCAPING_EDGES,(d.callnode.node,d.context)),C);A.solver.add_forall_constraint(var,ListenerKey(Listener.ESCAPING),A._cached_escaping_reachability_handler)
	def invoke_unknown(A,d):
		A.return_value(d,UnknownToken())
		for B in d.args.args:
			if isinstance(B,Token|ConstraintVar):A.register_escaping(B,d)
		for(D,C)in d.args.kwargs or():
			if D is not _A and isinstance(C,Token|ConstraintVar):A.register_escaping(C,d)
	def _app_import_hack(G,src,name):
		E=src;B=name;F=_A if(H:=E.spec.origin)is _A else Path(H).parts;A=[]
		for C in G.a.program.initial_imports:
			if C.endswith(B)and(len(B)==len(C)or C[-len(B)-1]=='.')and(D:=G.a.modules.get(C))is not _A and D.kind==ModuleKind.APP and D is not E:
				if F is _A:return D
				A.append(D)
		if not A:return
		elif len(A)==1:return A[0]
		if logger.isEnabledFor(logging.DEBUG):logger.debug("Multiple candidates for module '%s' from '%s': %s",B,E.name,A)
		assert F is not _A
		def I(info):
			if(C:=info.spec.origin)is _A:return 1<<30,0
			A=Path(C).parts;B=0
			for(D,E)in zip(A,F,strict=_C):
				if D!=E:break
				B+=1
			return-B,len(A)
		return min(A,key=I)
	def import_module(A,name,node,caller,*,warn_if_missing=_B):
		D=caller;C=name
		try:B=A.importer.import_module(C,warn_if_missing=warn_if_missing)
		except ModuleNotFoundError:
			if util.is_stdlib_module(C)or(E:=A.a.modules[source_module(D)]).kind!=ModuleKind.APP or(B:=A._app_import_hack(E,C))is _A:return UnknownToken(),_A
			A.a.diagnostics.patched_app_imports+=1;logger.warning("Patched unresolved import of '%s' in '%s' to '%s'",C,E.name,B.name)
		A.a.register_import(D,node,B.name);F=_A;H=any(fnmatch(B.name,A)for A in A.a.options.tracked_modules)
		if H:G=ImportAccessPath(B.name);A.a.access_paths_manager.add_import_access_path(G);F=AccessPathToken(G)
		return UnknownToken()if B.excluded else ModuleToken(B.name),F
	def absolute_import(F,name,asname,node,caller):
		A=name;assert not A.startswith('.');E,H,G=A.partition('.');C,B=F.import_module(A,node,caller)
		if asname is _A:
			D=C.id if isinstance(C,ModuleToken)else B.access_path.module_identifier if B and isinstance(B.access_path,ImportAccessPath)else A
			if D!=A:assert D.endswith('.'+A)or(D,A)==('typing','typing_extensions');E=D.removesuffix('.'+G)if G else D
			if isinstance(C,ModuleToken):assert E in F.a.modules;C=ModuleToken(ModuleIdentifier(E))
			if B:B=AccessPathToken(ImportAccessPath(ModuleIdentifier(E)))
		return C,B
def _find_escaping_fun(t):
	match t:
		case FunctionToken():return t
		case BoundMethodToken(A):return _find_escaping_fun(A)
		case _:pass